package com.clipstudio.app

/** Recebe cada linha de saida do yt-dlp (chamado pelo Python via Chaquopy). */
interface LineSink {
    fun line(s: String)
}
