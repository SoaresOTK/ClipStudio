package com.clipstudio.app

class YtResult(
    @JvmField val code: Int,
    @JvmField val out: String,
    @JvmField val err: String,
)
