package com.clipstudio.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Process

/**
 * Reinicia o app do zero (roda em um processo separado, ":restart").
 * Usado depois que a pasta de trabalho muda, porque o servidor Python so le a pasta ao iniciar.
 */
class RestartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = intent.getIntExtra("pid", -1)
        if (pid > 0 && pid != Process.myPid()) Process.killProcess(pid)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
        Runtime.getRuntime().exit(0)
    }
}
