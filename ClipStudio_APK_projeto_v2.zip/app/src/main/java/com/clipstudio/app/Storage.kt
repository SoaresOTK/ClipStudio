package com.clipstudio.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File

/**
 * Onde ficam os videos do ClipStudio.
 *
 * Pasta nova (padrao):  Memoria interna/ClipStudio            (/storage/emulated/0/ClipStudio)
 * Pasta antiga:         Android/data/com.clipstudio.app/files/ClipStudio  (restrita nos celulares novos)
 *
 * Para gravar na memoria interna o Android 11+ exige a permissao "Acesso a todos os arquivos".
 * Sem ela o app continua funcionando na pasta antiga.
 */
object Storage {
    const val FOLDER = "ClipStudio"
    private const val PREFS = "clipstudio"
    private const val KEY_SKIP = "pular_pasta"

    /** true quando o servidor esta usando a pasta da memoria interna. Definido no boot. */
    @Volatile var usingShared = false

    /** true depois que o usuario pediu, pelos Ajustes, para mudar de pasta. */
    @Volatile var pendingMove = false

    fun sharedRoot(): File = File(Environment.getExternalStorageDirectory(), FOLDER)

    fun legacyRoot(c: Context): File = File(c.getExternalFilesDir(null) ?: c.filesDir, FOLDER)

    fun hasAccess(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Abre a tela do Android que libera o acesso (ou o pedido comum no Android 10). */
    fun request(a: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + a.packageName))
                )
            } catch (e: Exception) {
                runCatching { a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }
        } else {
            a.requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 7
            )
        }
    }

    fun skipped(c: Context): Boolean = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SKIP, false)

    fun setSkipped(c: Context, v: Boolean) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SKIP, v).apply()
    }

    /** true se o caminho esta na memoria interna visivel (fora de Android/data). */
    fun isShared(path: String): Boolean {
        val base = Environment.getExternalStorageDirectory().absolutePath.trimEnd('/')
        val p = File(path).absolutePath
        return p.startsWith("$base/") && !p.startsWith("$base/Android/")
    }

    /** Escolhe a pasta de trabalho: memoria interna se der para gravar la, senao a pasta antiga. */
    fun pickRoot(c: Context): File {
        if (hasAccess(c)) {
            val r = sharedRoot()
            if (canWrite(r)) {
                usingShared = true
                return r
            }
        }
        usingShared = false
        return legacyRoot(c).apply { mkdirs() }
    }

    private fun canWrite(dir: File): Boolean = try {
        dir.mkdirs()
        val t = File(dir, ".teste_clipstudio")
        t.writeText("ok")
        t.delete()
        dir.isDirectory
    } catch (e: Throwable) {
        false
    }

    /**
     * Leva o que estava na pasta antiga para a memoria interna, mantendo as subpastas
     * (baixados/Projeto/arquivo.mp4 continua com o mesmo caminho relativo, entao o app nao perde nada).
     * Nunca sobrescreve: se ja existir um arquivo igual no destino, o antigo fica onde esta.
     * Devolve quantos arquivos foram movidos.
     */
    fun migrate(c: Context, onProgress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val from = legacyRoot(c)
        val to = sharedRoot()
        if (!from.isDirectory || from.absolutePath == to.absolutePath) return 0
        val files = from.walkTopDown().filter { it.isFile }.toList()
        if (files.isEmpty()) return 0
        var moved = 0
        files.forEachIndexed { i, src ->
            onProgress(i + 1, files.size)
            try {
                val dst = File(to, src.relativeTo(from).path)
                if (dst.exists()) return@forEachIndexed
                dst.parentFile?.mkdirs()
                if (!src.renameTo(dst)) {
                    val tmp = File(dst.parentFile, dst.name + ".movendo")
                    src.inputStream().use { input -> tmp.outputStream().use { out -> input.copyTo(out, 1 shl 20) } }
                    if (tmp.length() == src.length() && tmp.renameTo(dst)) {
                        dst.setLastModified(src.lastModified())
                        src.delete()
                    } else {
                        tmp.delete()
                        return@forEachIndexed
                    }
                }
                moved++
            } catch (e: Throwable) {
                // segue para o proximo arquivo; o que nao moveu continua na pasta antiga
            }
        }
        // apaga as pastas que ficaram vazias
        from.walkBottomUp().filter { it.isDirectory && it != from }.forEach { d ->
            if (d.list()?.isEmpty() == true) d.delete()
        }
        return moved
    }
}
