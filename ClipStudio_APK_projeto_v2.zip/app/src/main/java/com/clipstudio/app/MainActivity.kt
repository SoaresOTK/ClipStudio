package com.clipstudio.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    companion object {
        const val EXTRA_ASK_STORAGE = "pedir_pasta"
        private const val BG = "#0A0B12"
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var splash: LinearLayout
    private lateinit var splashText: TextView
    private var gate: View? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val pickCode = 42
    @Volatile private var alive = true
    private var appStarted = false

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor(BG))
            fitsSystemWindows = true
        }
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor(BG))
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.textZoom = 100   // o layout de celular ja usa tamanhos proprios
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    if (r.url.host == "127.0.0.1") return false
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, r.url)) }
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
                ): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = cb
                    return try {
                        startActivityForResult(params.createIntent(), pickCode)
                        true
                    } catch (e: Exception) {
                        fileCb = null
                        false
                    }
                }
            }
        }
        splashText = TextView(this).apply {
            setTextColor(Color.parseColor("#8E94A8"))
            textSize = 14f
            gravity = Gravity.CENTER
            text = "Iniciando…"
        }
        splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            setBackgroundColor(Color.parseColor(BG))
            addView(ImageView(context).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(dp(84), dp(84)))
            addView(TextView(context).apply {
                text = "ClipStudio"
                setTextColor(Color.parseColor("#F2F3F8"))
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(16) })
            addView(splashText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        }
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(splash, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        // Primeira abertura sem acesso a memoria interna: explica e pede a permissao antes de iniciar.
        if (!ServerService.running && !Storage.hasAccess(this) && !Storage.skipped(this)) showGate()
        else startApp()
    }

    /** Liga o servico (servidor Python) e espera ele responder para abrir a interface. */
    private fun startApp() {
        if (appStarted) return
        appStarted = true
        startForegroundService(Intent(this, ServerService::class.java))
        waitForServer()
    }

    // ------------------------------------------------------------ tela de permissao da pasta
    private fun pill(color1: String, color2: String?, radius: Int, stroke: String? = null) = GradientDrawable().apply {
        if (color2 != null) {
            orientation = GradientDrawable.Orientation.LEFT_RIGHT
            colors = intArrayOf(Color.parseColor(color1), Color.parseColor(color2))
        } else setColor(Color.parseColor(color1))
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), Color.parseColor(stroke))
    }

    private fun showGate() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.parseColor(BG))
            isClickable = true
        }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f) =
            LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top) }

        box.addView(View(this), lp(match, 0, 0, 1f))
        box.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, lp(dp(88), dp(88)))
        box.addView(TextView(this).apply {
            text = "Seus vídeos na memória interna"
            setTextColor(Color.parseColor("#F2F3F8"))
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp(match, wrap, 24))
        box.addView(TextView(this).apply {
            text = "O ClipStudio guarda os vídeos baixados e os clipes na pasta \"ClipStudio\" da memória interna, " +
                "fácil de achar no app Arquivos e na Galeria.\n\nPara isso o Android pede a permissão " +
                "\"Acesso a todos os arquivos\". Toque em Permitir, ative a chave e volte para o app."
            setTextColor(Color.parseColor("#8E94A8"))
            textSize = 15f
            setLineSpacing(dp(3).toFloat(), 1f)
            gravity = Gravity.CENTER
        }, lp(match, wrap, 12))
        box.addView(TextView(this).apply {
            text = "Memória interna  ›  ClipStudio"
            setTextColor(Color.parseColor("#B9B2FF"))
            textSize = 14f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            background = pill("#1A1D29", null, 12, "#2A2E3F")
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }, lp(match, wrap, 20))
        box.addView(View(this), lp(match, 0, 0, 1f))
        box.addView(TextView(this).apply {
            text = "Permitir acesso"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = pill("#7C6CFF", "#4DA3FF", 16)
            isClickable = true
            setOnClickListener { Storage.request(this@MainActivity) }
        }, lp(match, dp(54)))
        box.addView(TextView(this).apply {
            text = "Agora não (usar a pasta restrita do app)"
            setTextColor(Color.parseColor("#8E94A8"))
            textSize = 14f
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener {
                Storage.setSkipped(this@MainActivity, true)
                hideGate()
                startApp()
            }
        }, lp(match, dp(48), 6))
        gate = box
        root.addView(box, match, match)
    }

    private fun hideGate() {
        gate?.let { root.removeView(it) }
        gate = null
    }

    override fun onResume() {
        super.onResume()
        val ok = Storage.hasAccess(this)
        if (gate != null && ok) {          // voltou da tela de permissao com o acesso liberado
            hideGate()
            startApp()
        } else if (ok && Storage.pendingMove && ServerService.running && !Storage.usingShared) {
            // pediu a mudanca pelos Ajustes: reinicia para o servidor usar a pasta nova
            Storage.pendingMove = false
            Storage.setSkipped(this, false)
            restartApp()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_ASK_STORAGE, false)) {
            // o onResume que vem logo depois reinicia o app se o acesso ja estiver liberado
            Storage.pendingMove = true
            if (!Storage.hasAccess(this)) Storage.request(this)
        }
    }

    private fun restartApp() {
        splashText.text = "Mudando a pasta para a memória interna…"
        splash.visibility = View.VISIBLE
        startActivity(
            Intent(this, RestartActivity::class.java)
                .putExtra("pid", Process.myPid())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    private fun waitForServer() {
        Thread {
            val url = "http://127.0.0.1:${ServerService.PORT}"
            while (alive) {
                runOnUiThread { splashText.text = ServerService.status }
                val ok = try {
                    val c = URL("$url/api/ping").openConnection() as HttpURLConnection
                    c.connectTimeout = 800
                    c.readTimeout = 800
                    c.responseCode == 200
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    runOnUiThread {
                        splash.visibility = View.GONE
                        web.loadUrl(url)
                    }
                    return@Thread
                }
                Thread.sleep(700)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == pickCode) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (gate != null) { moveTaskToBack(true); return }
        // a interface trata o "voltar" (fecha telas e paineis abertos); se nao houver nada aberto, minimiza
        web.evaluateJavascript("(window.csBack && window.csBack()) ? '1' : '0'") { r ->
            if (r == null || !r.contains("1")) moveTaskToBack(true)   // nao encerra o servidor
        }
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
    }
}
