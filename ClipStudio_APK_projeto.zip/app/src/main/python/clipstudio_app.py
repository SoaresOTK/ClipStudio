#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ClipStudio - clipes verticais de gameplay (uso pessoal).

Roda um pequeno servidor local (so no seu PC, 127.0.0.1) e abre a interface
em uma janela. Usa o yt-dlp para baixar e o FFmpeg para montar os clipes.
Nao precisa instalar nenhuma biblioteca Python.

Pastas (ao lado do ClipStudio.bat):
  baixados/   videos e trechos baixados
  clipes/     clipes verticais prontos
"""
import array
import hashlib
import json
import math
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APK = bool(os.environ.get("CLIPSTUDIO_ANDROID"))   # rodando dentro do app (APK)
ANDROID = APK or bool(os.environ.get("TERMUX_VERSION")) or "com.termux" in os.environ.get("PREFIX", "")
FROZEN = getattr(sys, "frozen", False)   # True quando roda como ClipStudio.exe
if FROZEN:
    RES_DIR = Path(getattr(sys, "_MEIPASS", ".")).resolve()          # arquivos embutidos no .exe
    ROOT = Path(os.environ.get("CLIPSTUDIO_ROOT") or Path(sys.executable).resolve().parent).resolve()
    APP_DIR = ROOT / "clipstudio"                                     # dados e ajustes ficam ao lado do .exe
elif APK:
    APP_DIR = Path(os.environ["CLIPSTUDIO_APPDIR"]).resolve()      # pasta interna do app (ui.html, fontes, ajustes)
    RES_DIR = APP_DIR
    ROOT = Path(os.environ["CLIPSTUDIO_ROOT"]).resolve()
else:
    APP_DIR = Path(__file__).resolve().parent
    RES_DIR = APP_DIR
    _shared = Path.home() / "storage" / "shared"
    _def_root = (_shared / "ClipStudio") if (ANDROID and _shared.is_dir()) else APP_DIR.parent
    ROOT = Path(os.environ.get("CLIPSTUDIO_ROOT") or _def_root).resolve()
FONTS_DIR = APP_DIR / "fontes"
DL_DIR = ROOT / "baixados"
CLIP_DIR = ROOT / "clipes"
# pastas antigas (do clipes.ps1) que tambem aparecem nas abas
DL_SCAN = [DL_DIR, ROOT, ROOT / "raw"]
CLIP_SCAN = [CLIP_DIR, ROOT / "out"]
CACHE = APP_DIR / "cache"
DB_FILE = APP_DIR / "dados.json"
CFG_FILE = APP_DIR / "config.json"
INBOX = ROOT / "momentos.txt"
PORT = int(os.environ.get("CLIPSTUDIO_PORT") or 8765)
VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov"}
NOWIN = 0x08000000 if os.name == "nt" else 0  # nao abrir janelas pretas

DEFAULT_PROFILE = {
    # regioes em fracao do quadro original (0..1), medidas no video do Edu
    "cam": {"x": 1434 / 1920, "y": 52 / 1080, "w": 440 / 1920, "h": 232 / 1080},
    "game": {"x": 528 / 1920, "y": 0.0, "w": 864 / 1920, "h": 1.0},
    "top_h": 570,          # altura do painel da camera (jogo = 1920 - top_h)
    "layout": "cam_game",  # fit (video inteiro + fundo) | fill (preencher) | cam_game | split
    "font_size": 76,
    "out": "9x16",         # formato do clipe: 9x16 | 4x5 | 1x1
    "fit_ar": "orig",      # layout fit: orig | 4x3 | 1x1 (proporcao do video do meio)
    "pos_x": 0.5,          # posicao horizontal do corte (fit 4x3/1x1 e fill)
    "bg": "blur",          # fundo do layout fit: blur | black
    "blur": 50,            # intensidade do desfoque (0..100)
    "title_font": "Impact",
    "title_color": "#000000",
    "title_box": True,           # caixa atras do texto; sem caixa o texto ganha contorno
    "title_box_color": "#FFFFFF",
    "title_outline_color": "#000000",
    "title_align": "center",     # left | center | right
    "title_bold": False, "title_italic": False, "title_under": False, "title_upper": True,
    "title_pos": 0,              # altura em % do clipe; 0 = automatico (depende do layout)
    "logo": "",            # arquivo em clipstudio/logos
    "logo_pos": "bl",      # tl | tr | bl | br | bc
    "logo_size": 30,       # largura da logo em % da largura do clipe
    "cap_on": False,       # legenda animada ligada por padrao neste perfil
    "cap_size": 84,
    "cap_color": "#3BEB3B",  # cor da palavra que esta sendo falada
    "cap_pos": 72,         # altura do centro da legenda, em % da altura do clipe
    "cap_words": 4,        # palavras por bloco
    "cap_upper": True,
    "cap_font": "Arial Black",   # nome de uma fonte instalada no Windows
    "cap_text_color": "#FFFFFF",
    "cap_outline_color": "#000000",
    "cap_outline": 8,            # grossura do contorno
    "cap_shadow": 0,
    "cap_hl": True,              # destacar a palavra falada
    "cap_grow": False,           # a palavra destacada fica um pouco maior
    "cap_align": "center",
    "cap_bold": True, "cap_italic": False, "cap_under": False,
}
BOOL_KEYS = ("cap_on", "cap_upper", "cap_hl", "cap_grow", "cap_bold", "cap_italic", "cap_under",
             "title_box", "title_bold", "title_italic", "title_under", "title_upper")
COLOR_KEYS = ("cap_color", "cap_text_color", "cap_outline_color", "title_color", "title_box_color", "title_outline_color")
FONT_KEYS = ("cap_font", "title_font")
WORDS_DIR = APP_DIR / "legendas"
OUT_SIZES = {"9x16": (1080, 1920), "4x5": (1080, 1350), "1x1": (1080, 1080)}
LAYOUTS = ("fit", "fill", "cam_game", "split")
LOGO_DIR = APP_DIR / "logos"
LOGO_RE = re.compile(r"^[0-9a-f]{16}\.(png|jpg|webp)$")


def fix_profile(p):
    """Atualiza perfis salvos por versoes antigas."""
    if p.get("layout") == "game_only":
        g = p.get("game") or DEFAULT_PROFILE["game"]
        p["layout"] = "fill"
        p["pos_x"] = min(max(g["x"] + g["w"] / 2.0, 0.0), 1.0)
    if "title_box" not in p and "title_style" in p:      # versao anterior: estilo unico
        if p.get("title_style") == "outline":
            p.update(title_box=False, title_color="#FFFF00", title_font="Arial Black")
        else:
            p["title_box"] = True
    p.pop("title_style", None)
    return p
DEFAULT_CFG = {
    "profiles": {"Padrão": DEFAULT_PROFILE},   # um perfil de layout por canal/jogo
    "active": "Padrão",
    "channels": {},        # canal do YouTube -> perfil usado por ultimo
    "crf": 20,
    "max_height": 1080,
    "tags": "#shorts #gameplay",
    "encoder": "cpu",      # cpu (libx264) | gpu (placa de video AMD, h264_amf)
}

LOCK = threading.RLock()
BOOT = int(time.time())
LAST_SEEN = [time.time()]   # ultima vez que a janela falou com o programa


# ----------------------------------------------------------------- utilidades
def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    tmp = Path(str(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def get_cfg():
    cfg = json.loads(json.dumps(DEFAULT_CFG))
    saved = load_json(CFG_FILE, {})
    if "profiles" not in saved and "cam" in saved:  # config da versao 1
        prof = dict(DEFAULT_PROFILE)
        prof.update({k: saved[k] for k in DEFAULT_PROFILE if k in saved})
        saved = {"profiles": {"Padrão": prof}, "crf": saved.get("crf", 20),
                 "max_height": saved.get("max_height", 1080)}
    for k in cfg:
        if k in saved:
            cfg[k] = saved[k]
    if not isinstance(cfg["profiles"], dict) or not cfg["profiles"]:
        cfg["profiles"] = {"Padrão": json.loads(json.dumps(DEFAULT_PROFILE))}
    if cfg["active"] not in cfg["profiles"]:
        cfg["active"] = next(iter(cfg["profiles"]))
    for p in cfg["profiles"].values():
        if isinstance(p, dict):
            fix_profile(p)
    if not isinstance(cfg["channels"], dict):
        cfg["channels"] = {}
    return cfg


def flat_cfg(profile=None, cfg=None):
    """Perfil + ajustes gerais em um dicionario so (usado para montar o clipe)."""
    cfg = cfg or get_cfg()
    out = json.loads(json.dumps(DEFAULT_PROFILE))
    out.update(cfg["profiles"].get(profile) or cfg["profiles"][cfg["active"]])
    out["crf"] = cfg["crf"]
    out["max_height"] = cfg["max_height"]
    out["encoder"] = "gpu" if cfg.get("encoder") == "gpu" else "cpu"
    return out


def resolve_profile(name, fid, db=None, cfg=None):
    """Escolhe o perfil: o pedido, o ultimo usado no video, o do canal, ou o ativo."""
    cfg = cfg or get_cfg()
    if name in cfg["profiles"]:
        return name
    meta = (db or get_db())["downloads"].get(fid or "", {})
    if meta.get("profile") in cfg["profiles"]:
        return meta["profile"]
    ch = cfg["channels"].get(meta.get("uploader") or "")
    return ch if ch in cfg["profiles"] else cfg["active"]


def clean_profile(c, base=None):
    """Valida um perfil vindo da interface."""
    out = json.loads(json.dumps(DEFAULT_PROFILE))
    out.update(base or {})
    for key in ("cam", "game"):
        r = c.get(key)
        if isinstance(r, dict):
            try:
                x, y, w, h = (float(r[k]) for k in ("x", "y", "w", "h"))
            except Exception:
                continue
            w = min(max(w, 0.02), 1.0)
            h = min(max(h, 0.02), 1.0)
            x = min(max(x, 0.0), 1.0 - w)
            y = min(max(y, 0.0), 1.0 - h)
            out[key] = {"x": x, "y": y, "w": w, "h": h}
    try:
        out["top_h"] = int(min(max(int(c.get("top_h", out["top_h"])), 200), 1400)) // 2 * 2
        out["font_size"] = int(min(max(int(c.get("font_size", out["font_size"])), 20), 200))
    except Exception:
        pass
    c = fix_profile(dict(c))
    if c.get("layout") in LAYOUTS:
        out["layout"] = c["layout"]
    out.pop("title_style", None)
    for key, vals in (("out", OUT_SIZES), ("fit_ar", ("orig", "4x3", "1x1")), ("bg", ("blur", "black")),
                      ("title_align", ("left", "center", "right")), ("cap_align", ("left", "center", "right")),
                      ("logo_pos", ("tl", "tr", "bl", "br", "bc"))):
        if c.get(key) in vals:
            out[key] = c[key]
    try:
        out["pos_x"] = min(max(float(c.get("pos_x", out["pos_x"])), 0.0), 1.0)
        out["blur"] = int(min(max(int(c.get("blur", out["blur"])), 0), 100))
        out["logo_size"] = int(min(max(int(c.get("logo_size", out["logo_size"])), 8), 80))
    except Exception:
        pass
    try:
        out["cap_size"] = int(min(max(int(c.get("cap_size", out["cap_size"])), 30), 180))
        out["cap_pos"] = int(min(max(int(c.get("cap_pos", out["cap_pos"])), 8), 95))
        out["cap_words"] = int(min(max(int(c.get("cap_words", out["cap_words"])), 1), 8))
    except Exception:
        pass
    try:
        out["cap_outline"] = int(min(max(int(c.get("cap_outline", out["cap_outline"])), 0), 30))
        out["cap_shadow"] = int(min(max(int(c.get("cap_shadow", out["cap_shadow"])), 0), 20))
        out["title_pos"] = int(min(max(int(c.get("title_pos", out["title_pos"])), 0), 95))
    except Exception:
        pass
    for key in FONT_KEYS:
        fnt = re.sub(r"\s+", " ", str(c.get(key) or "")).strip()
        if re.match(r"^[\w .'&+-]{2,50}$", fnt):
            out[key] = fnt
    for key in COLOR_KEYS:
        if re.match(r"^#[0-9a-fA-F]{6}$", str(c.get(key) or "")):
            out[key] = c[key]
    for key in BOOL_KEYS:
        if key in c:
            out[key] = bool(c[key])
    if "logo" in c:
        lg = str(c.get("logo") or "")
        out["logo"] = lg if LOGO_RE.match(lg) and (LOGO_DIR / lg).is_file() else ""
    return out


def get_db():
    db = load_json(DB_FILE, {})
    db.setdefault("downloads", {})
    db.setdefault("clips", {})
    return db



# ------------------------------------------------ yt-dlp dentro do APK (ponte Kotlin)
def _bridge():
    from java import jclass
    return jclass("com.clipstudio.app.Bridge")


def _make_sink(q):
    from java import dynamic_proxy, jclass

    class Sink(dynamic_proxy(jclass("com.clipstudio.app.LineSink"))):
        def line(self, s):
            q.put((str(s) + "\n").encode("utf-8", "replace"))
    return Sink()


class _ShimOut:
    def __init__(self, q):
        self.q, self.buf, self.eof = q, b"", False

    def read1(self, n=4096):
        if self.buf:
            d, self.buf = self.buf[:n], self.buf[n:]
            return d
        if self.eof:
            return b""
        item = self.q.get()
        if item is None:
            self.eof = True
            return b""
        self.buf = item[n:]
        return item[:n]


class _ShimProc:
    """Imita um subprocess para o yt-dlp, que roda pela biblioteca youtubedl-android."""
    _seq = [0]

    def __init__(self, args):
        from java import jarray, jclass
        _ShimProc._seq[0] += 1
        self.pid_ = "cs%d" % _ShimProc._seq[0]
        self.q = queue.Queue()
        self.stdout = _ShimOut(self.q)
        self.returncode = None
        self.out = ""
        self.err = ""
        self._done = threading.Event()
        jargs = jarray(jclass("java.lang.String"))([str(a) for a in args])
        threading.Thread(target=self._go, args=(jargs,), daemon=True).start()

    def _go(self, jargs):
        try:
            res = _bridge().ytdlp(jargs, self.pid_, _make_sink(self.q))
            self.out, self.err = str(res.out or ""), str(res.err or "")
            for l in self.err.splitlines():
                self.q.put((l + "\n").encode("utf-8", "replace"))
            self.returncode = int(res.code)
        except Exception as e:  # noqa
            self.err = "ERROR: %s" % e
            self.q.put((self.err + "\n").encode("utf-8", "replace"))
            self.returncode = 1
        finally:
            self.q.put(None)
            self._done.set()

    def wait(self, timeout=None):
        self._done.wait(timeout)
        return self.returncode

    def poll(self):
        return self.returncode if self._done.is_set() else None

    def terminate(self):
        try:
            _bridge().cancel(self.pid_)
        except Exception:
            pass

    kill = terminate


def _is_ytdlp(cmd):
    return APK and bool(cmd) and cmd[0] == "yt-dlp"


class _Result:
    pass


def _run(cmd, **kw):
    """subprocess.run, mas o yt-dlp passa pela ponte do APK."""
    if _is_ytdlp(cmd):
        p = _ShimProc(cmd[1:])
        if not p._done.wait(kw.get("timeout")):
            p.terminate()
            raise subprocess.TimeoutExpired(cmd, kw.get("timeout"))
        r = _Result()
        r.returncode = p.returncode
        r.stdout = p.out.encode("utf-8", "replace")
        r.stderr = p.err.encode("utf-8", "replace")
        return r
    return subprocess.run(cmd, **kw)


def _popen(cmd, **kw):
    if _is_ytdlp(cmd):
        return _ShimProc(cmd[1:])
    return subprocess.Popen(cmd, **kw)


def _gallery(path):
    """Copia o clipe pronto para a Galeria (Filmes/ClipStudio)."""
    if APK:
        try:
            _bridge().saveToGallery(str(path))
        except Exception as e:  # noqa
            print("Aviso: nao consegui copiar para a Galeria:", e)


def find_tool(name):
    if APK:   # no APK: yt-dlp e FFmpeg vem da biblioteca youtubedl-android
        if name == "yt-dlp":
            return "yt-dlp"
        if name == "ffmpeg":
            return os.environ.get("CLIPSTUDIO_FFMPEG") or None
        return None
    exe = name + (".exe" if os.name == "nt" else "")
    for d in (ROOT, APP_DIR):
        if (d / exe).is_file():
            return str(d / exe)
    return shutil.which(name)


def safe_name(text, maxlen=70):
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f%]', " ", str(text or ""))
    text = re.sub(r"\s+", " ", text).strip(" .")
    return text[:maxlen].strip(" .") or "video"


def unique_path(folder, base, ext=".mp4"):
    p = folder / (base + ext)
    n = 2
    while p.exists() or p in ACTIVE_OUT:
        p = folder / ("%s_%d%s" % (base, n, ext))
        n += 1
    return p


def file_id(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def resolve_id(fid, scan):
    """Converte o id (caminho relativo) em arquivo, so dentro das pastas do app."""
    if not fid or "\x00" in fid:
        return None
    p = (ROOT / fid).resolve()
    if p.suffix.lower() not in VIDEO_EXT or not p.is_file():
        return None
    if not _in_scan(p, scan):
        return None
    return p


def _in_scan(p, scan):
    bases = (DL_DIR.resolve(), CLIP_DIR.resolve())
    for d in scan:
        d = d.resolve()
        if p.parent == d or (d in bases and p.parent.parent == d):
            return True
    return False


def project_of(p):
    """Nome do projeto (pasta do video) de um arquivo, ou '' se estiver solto."""
    p = Path(p).resolve()
    if p.parent.parent in (DL_DIR.resolve(), CLIP_DIR.resolve()):
        return p.parent.name
    return ""


def migrate_projects():
    """Move os arquivos soltos em baixados/ e clipes/ para a pasta do video deles."""
    with LOCK:
        db = get_db()
        titles = {m.get("url"): m["video"] for m in db["downloads"].values() if m.get("video") and m.get("url")}
        moved = {}
        for fid, m in list(db["downloads"].items()):
            p = ROOT / fid
            video = m.get("video") or titles.get(m.get("url"))
            if not video or not p.is_file() or p.parent.resolve() != DL_DIR.resolve():
                continue
            dest = DL_DIR / safe_name(video, 60) / p.name
            try:
                dest.parent.mkdir(exist_ok=True)
                if dest.exists():
                    continue
                p.rename(dest)
            except OSError:
                continue
            m["video"] = video
            db["downloads"][file_id(dest)] = db["downloads"].pop(fid)
            moved[fid] = file_id(dest)
        for c in db["clips"].values():
            if c.get("source") in moved:
                c["source"] = moved[c["source"]]
        for fid, c in list(db["clips"].items()):
            p = ROOT / fid
            proj = project_of(ROOT / c["source"]) if c.get("source") else ""
            if not proj or not p.is_file() or p.parent.resolve() != CLIP_DIR.resolve():
                continue
            dest = CLIP_DIR / proj / p.name
            try:
                dest.parent.mkdir(exist_ok=True)
                if dest.exists():
                    continue
                p.rename(dest)
            except OSError:
                continue
            db["clips"][file_id(dest)] = db["clips"].pop(fid)
            moved[fid] = file_id(dest)
        if moved:
            save_json(DB_FILE, db)


def fmt_ts(sec):
    sec = int(round(float(sec)))
    h, m, s = sec // 3600, sec % 3600 // 60, sec % 60
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


_PROBE = {}


def probe(path):
    st = path.stat()
    key = (str(path), st.st_mtime_ns, st.st_size)
    if key in _PROBE:
        return _PROBE[key]
    info = {"w": 0, "h": 0, "dur": 0.0}
    ffprobe = find_tool("ffprobe")
    if ffprobe:
        try:
            out = subprocess.run(
                [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=width,height:format=duration", "-of", "json", str(path)],
                capture_output=True, stdin=subprocess.DEVNULL, timeout=30, creationflags=NOWIN).stdout
            j = json.loads(out.decode("utf-8", "replace") or "{}")
            s = (j.get("streams") or [{}])[0]
            info = {"w": int(s.get("width") or 0), "h": int(s.get("height") or 0),
                    "dur": float((j.get("format") or {}).get("duration") or 0)}
        except Exception:
            pass
    elif find_tool("ffmpeg"):   # sem ffprobe (APK): le a duracao e o tamanho pelo ffmpeg -i
        try:
            r = subprocess.run([find_tool("ffmpeg"), "-hide_banner", "-i", str(path)], capture_output=True,
                               stdin=subprocess.DEVNULL, timeout=30, creationflags=NOWIN)
            txt = r.stderr.decode("utf-8", "replace")
            m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", txt)
            v = re.search(r"Video:.*?,\s*(\d{2,5})x(\d{2,5})\b", txt)
            if v:
                info = {"w": int(v.group(1)), "h": int(v.group(2)),
                        "dur": (int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))) if m else 0.0}
        except Exception:
            pass
    if info["w"]:
        _PROBE[key] = info
    return info


# -------------------------------------------------------- leitor de momentos
_TS = r"(?:(\d{1,2}):)?(\d{1,3}):(\d{2})(?!\d)"
_TS_RE = re.compile(r"(?<![\d:])" + _TS)
_URL_RE = re.compile(r"https?://(?:www\.|m\.)?(?:youtube\.com|youtu\.be)/\S+", re.I)
_JUNK = {"copiar", "copiado", "copiado!", "copy", "copied", "copied!", "compartilhar", "share"}


def _secs(m):
    h, mm, ss = m.group(1), m.group(2), m.group(3)
    return int(h or 0) * 3600 + int(mm) * 60 + int(ss)


def parse_moments(text):
    """Le uma lista colada (ex.: do site de melhores momentos).

    Aceita linhas como:
      12:30 - 13:45  Descricao
      [1:02:10 – 1:03:00] Descricao
      12:30 Descricao            (so o inicio: o fim vira o proximo inicio)
    e descricoes na linha de baixo do horario.
    """
    url = None
    items = []
    cur = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        mu = _URL_RE.search(line)
        if mu and not url:
            url = mu.group(0).rstrip(").,;")
        if mu:
            line = _URL_RE.sub("", line).strip()
            if not line:
                continue
        if line.lower() in _JUNK:
            continue
        if re.match(r"^[\s|:\-]+$", line):   # separador de tabela markdown
            continue
        head = re.sub(r"^[\s\-\*•#\[\(|]*(?:\d{1,3}[\.\)]\s+)?[\s\[\(*|]*", "", line)
        ms = list(_TS_RE.finditer(head))
        starts_with_ts = bool(ms) and ms[0].start() <= 2
        if starts_with_ts:
            start = _secs(ms[0])
            end = None
            rest_from = ms[0].end()
            if len(ms) >= 2:
                between = head[ms[0].end():ms[1].start()]
                if len(between) <= 8 and not re.search(r"[A-Za-zÀ-ÿ]{3,}", between.replace("até", "").replace("ate", "")):
                    end = _secs(ms[1])
                    rest_from = ms[1].end()
            desc = re.sub(r"^[\s\]\)\-–—:|•·>*]+", "", head[rest_from:]).strip()
            cur = {"start": start, "end": end, "desc": desc}
            items.append(cur)
        elif cur is not None:
            cur["desc"] = (cur["desc"] + " " + line).strip() if cur["desc"] else line
    # completa os fins que faltam
    for i, it in enumerate(items):
        if it["end"] is None or it["end"] <= it["start"]:
            nxt = items[i + 1]["start"] if i + 1 < len(items) else None
            if nxt is not None and 0 < nxt - it["start"] <= 180:
                it["end"] = nxt
            else:
                it["end"] = it["start"] + 60
        it["title"], it["score"], it["desc"] = _split_fields(re.sub(r"\s+", " ", it["desc"]))
    return {"url": url, "items": items}


def _split_fields(desc):
    """'titulo | 9 | motivo' -> (titulo, nota, motivo). Sem '|', tudo vira descricao."""
    if "|" not in desc:
        return "", None, desc[:300]
    score, rest = None, []
    for p in (x.strip(" *") for x in desc.split("|")):
        if not p:
            continue
        m = re.match(r"^(?:nota:?\s*)?(\d{1,2}(?:[.,]\d)?)(?:\s*/\s*10)?$", p, re.I)
        if m and score is None and float(m.group(1).replace(",", ".")) <= 10:
            score = float(m.group(1).replace(",", "."))
        else:
            rest.append(p)
    return (rest[0][:100] if rest else ""), score, " · ".join(rest[1:])[:300]


# ------------------------------------------------------------- transcricao
_TS_LINE = re.compile(r"^" + _TS + r"(?:[.,]\d{1,3})?")


def _clean_txt(t):
    t = re.sub(r"<[^>]+>", "", t)
    for a, b in (("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&#39;", "'"), ("&quot;", '"')):
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()


def parse_transcript(text):
    """Le legenda em json3 (YouTube), .srt/.vtt ou texto com horarios. -> [{t, text}]"""
    text = (text or "").lstrip("\ufeff")
    lines = []
    st = text.lstrip()
    if st.startswith("{") and '"events"' in st[:3000]:
        for ev in json.loads(st).get("events", []):
            t = _clean_txt("".join(sg.get("utf8", "") for sg in ev.get("segs") or []))
            if t:
                lines.append({"t": (ev.get("tStartMs") or 0) / 1000.0, "text": t})
    elif "-->" in text:
        cur, last = None, ""
        for raw in text.splitlines():
            line = raw.strip()
            m = re.match(r"^" + _TS + r"[.,]\d{1,3}\s*-->", line)
            if m:
                cur = _secs(m)
                continue
            if not line or line.isdigit() or line.startswith(("WEBVTT", "Kind:", "Language:", "NOTE")):
                continue
            t = _clean_txt(line)
            if cur is None or not t or t == last:   # legendas automaticas repetem a linha anterior
                continue
            last = t
            lines.append({"t": float(cur), "text": t})
    else:
        pend = None
        for raw in text.splitlines():
            line = re.sub(r"^[\s\-\*•#>\[\(|]+", "", raw.strip())
            if not line:
                continue
            m = _TS_LINE.match(line)
            if m:
                rest = _clean_txt(re.sub(r"^[\s\]\)\-–—:|*]+", "", line[m.end():]))
                if rest:
                    lines.append({"t": float(_secs(m)), "text": rest})
                    pend = None
                else:
                    pend = float(_secs(m))
            elif pend is not None:
                lines.append({"t": pend, "text": _clean_txt(line)})
                pend = None
            elif lines:
                lines[-1]["text"] += " " + _clean_txt(line)
    return lines


def merge_blocks(lines, span=8):
    """Junta as linhas curtas em blocos de alguns segundos (menos texto para a IA)."""
    out = []
    for l in sorted(lines, key=lambda x: x["t"]):
        if out and l["t"] - out[-1]["t"] < span and len(out[-1]["text"]) < 400:
            out[-1]["text"] += " " + l["text"]
        else:
            out.append({"t": round(l["t"], 1), "text": l["text"]})
    return out


def parse_words(text):
    """Legenda json3 do YouTube -> [[inicio_s, duracao_s, palavra], ...] (uma entrada por palavra)."""
    out = []
    for ev in json.loads(text).get("events", []):
        segs = ev.get("segs") or []
        base = ev.get("tStartMs") or 0
        dur = ev.get("dDurationMs") or 0
        timed = any("tOffsetMs" in sg for sg in segs)
        for sg in segs:
            ws = [w for w in re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", sg.get("utf8", "")).split() if w.strip("-–—>")]
            if not ws:
                continue
            t0 = base + (sg.get("tOffsetMs") or 0)
            if timed or len(ws) == 1:
                for i, w in enumerate(ws):
                    out.append([(t0 + i * 180) / 1000.0, 0.0, w])
            else:   # legenda sem horario por palavra: reparte o tempo da frase pelo tamanho das palavras
                tot = float(sum(len(w) + 1 for w in ws))
                acc = 0.0
                for w in ws:
                    out.append([(t0 + (dur or 2500) * acc / tot) / 1000.0, 0.0, w])
                    acc += len(w) + 1
    out.sort(key=lambda x: x[0])
    for i, w in enumerate(out):
        nxt = out[i + 1][0] if i + 1 < len(out) else w[0] + 0.6
        w[1] = round(min(max(nxt - w[0], 0.08), 1.5), 3)
        w[0] = round(w[0], 3)
    return out


def words_key(url):
    m = re.search(r"(?:v=|youtu\.be/|/shorts/|/live/|/embed/)([\w-]{11})", url or "")
    return m.group(1) if m else hashlib.md5((url or "").encode("utf-8")).hexdigest()[:16]


def save_words(url, text):
    try:
        words = parse_words(text)
    except Exception:
        return None
    if len(words) < 3:
        return None
    WORDS_DIR.mkdir(parents=True, exist_ok=True)
    save_json(WORDS_DIR / (words_key(url) + ".json"), words)
    return words


def fetch_words(url):
    """Palavras com horario do video inteiro (guardadas em clipstudio/legendas)."""
    f = WORDS_DIR / (words_key(url) + ".json")
    if f.is_file():
        w = load_json(f, [])
        if w:
            return w
    ytdlp = find_tool("yt-dlp")
    if not ytdlp:
        raise RuntimeError("yt-dlp não encontrado.")
    CACHE.mkdir(exist_ok=True)
    base = "pal_%d" % (time.time() * 1000)
    try:
        for langs in ("pt-orig,pt,pt-BR", ".*-orig", "en.*"):
            try:
                _run([ytdlp, "--no-playlist", "--skip-download", "--write-subs", "--write-auto-subs",
                                "--sub-langs", langs, "--sub-format", "json3", "--encoding", "utf-8",
                                "-o", str(CACHE / base) + ".%(ext)s", url],
                               capture_output=True, stdin=subprocess.DEVNULL, timeout=150, creationflags=NOWIN)
            except subprocess.TimeoutExpired:
                raise RuntimeError("O YouTube demorou demais para responder.")
            for sub in sorted(CACHE.glob(base + ".*.json3"), key=lambda p: ("-orig" not in p.name, len(p.name))):
                w = save_words(url, sub.read_text(encoding="utf-8", errors="replace"))
                if w:
                    return w
    finally:
        for sub in CACHE.glob(base + ".*"):
            try:
                sub.unlink()
            except OSError:
                pass
    raise RuntimeError("Esse vídeo não tem legenda automática no YouTube, então não dá para montar a legenda animada.")


def file_words(fid):
    """Palavras de um video baixado, com horarios relativos ao inicio do arquivo."""
    meta = get_db()["downloads"].get(fid or "", {})
    if not meta.get("url"):
        raise RuntimeError("Esse vídeo não foi baixado do YouTube pelo programa, então não tenho a legenda dele.")
    off = 0.0 if meta.get("full") else float(meta.get("start") or 0)
    src = resolve_id(fid, DL_SCAN)
    dur = probe(src)["dur"] if src else 0
    words = fetch_words(meta["url"])
    return [[round(t - off, 3), d, w] for t, d, w in words if t - off >= -0.2 and (not dur or t - off <= dur)]


def clean_caps(caps):
    out = []
    for it in caps if isinstance(caps, list) else []:
        try:
            t, d, w = float(it[0]), float(it[1]), re.sub(r"[{}\\\r\n]", "", str(it[2])).strip()[:40]
        except Exception:
            continue
        if w and d > 0:
            out.append([t, min(d, 3.0), w])
    out.sort(key=lambda x: x[0])
    return out[:4000]


def _ass_t(t):
    t = max(0.0, t)
    return "%d:%02d:%05.2f" % (int(t // 3600), int(t % 3600 // 60), t % 60)


def _ass_col(c, default="#FFFFFF"):
    c = str(c or default).lstrip("#")
    if not re.match(r"^[0-9a-fA-F]{6}$", c):
        c = default.lstrip("#")
    return "&H00%s%s%s" % (c[4:6], c[2:4], c[0:2])


ASS_HEAD = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: %d\nWrapStyle: %d\nScaledBorderAndShadow: yes\n\n"
            "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
            "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
            "MarginL, MarginR, MarginV, Encoding\n"
            "Style: S,%s,%d,%s,%s,%s,&H00000000,%d,%d,%d,0,100,100,0,0,%d,%d,%d,5,60,60,20,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
_ALIGN = {"left": (4, 60), "center": (5, 540), "right": (6, 1020)}


FONT_ALT = {"impact": "Anton", "arial black": "Archivo Black"}   # fora do Windows: equivalentes livres (pasta fontes)


def _ass_font(name, default):
    n = re.sub(r"[,\r\n]", " ", str(name or default))
    if os.name != "nt" and FONTS_DIR.is_dir():
        n = FONT_ALT.get(n.strip().lower(), n)
    return n


def build_ass(cfg, caps, OH, shift=0.0):
    """Legenda .ass: blocos de poucas palavras, com a palavra falada em outra cor."""
    size = int(cfg.get("cap_size", 84))
    nmax = int(cfg.get("cap_words", 4))
    base = _ass_col(cfg.get("cap_text_color"))
    hl = _ass_col(cfg.get("cap_color"), "#3BEB3B") if cfg.get("cap_hl", True) else None
    grow = bool(hl and cfg.get("cap_grow"))
    maxc = max(6, int((940 if grow else 1000) / (size * 0.72)))
    g_on, g_off = ("\\fscx118\\fscy118", "\\fscx100\\fscy100") if grow else ("", "")
    y = int(OH * int(cfg.get("cap_pos", 72)) / 100.0)
    an, x = _ALIGN.get(cfg.get("cap_align"), _ALIGN["center"])
    head = ASS_HEAD % (OH, 2, _ass_font(cfg.get("cap_font"), "Arial Black"), size, base, base,
                       _ass_col(cfg.get("cap_outline_color"), "#000000"),
                       -1 if cfg.get("cap_bold", True) else 0, -1 if cfg.get("cap_italic") else 0,
                       -1 if cfg.get("cap_under") else 0, 1, int(cfg.get("cap_outline", 8)), int(cfg.get("cap_shadow", 0)))
    blocks, cur = [], []
    for w in caps:
        if cur and (len(cur) >= nmax or w[0] - (cur[-1][0] + cur[-1][1]) > 0.7 or cur[-1][2][-1:] in ".?!"):
            blocks.append(cur)
            cur = []
        cur.append(w)
    if cur:
        blocks.append(cur)
    ev = []
    for bi, blk in enumerate(blocks):
        nxt = blocks[bi + 1][0][0] if bi + 1 < len(blocks) else 1e9
        txt = [(w[2].upper() if cfg.get("cap_upper", True) else w[2]) for w in blk]
        brk, ln = set(), 0          # quebra de linha depois dessas palavras
        for i, w in enumerate(txt):
            if ln and ln + 1 + len(w) > maxc:
                brk.add(i - 1)
                ln = 0
            ln += len(w) + (1 if ln else 0)
        for i, w in enumerate(blk):
            st = w[0] - shift
            en = (blk[i + 1][0] if i + 1 < len(blk) else min(w[0] + w[1] + 0.25, nxt)) - shift
            if en <= 0 or en <= st:
                continue
            parts = []
            for j, t in enumerate(txt):
                parts.append(("{\\c%s&%s}%s{\\c%s&%s}" % (hl, g_on, t, base, g_off)) if hl and j == i else t)
                if j < len(txt) - 1:
                    parts.append("\\N" if j in brk else " ")
            pop = "\\fscx88\\fscy88\\t(0,90,\\fscx100\\fscy100)" if i == 0 and st >= 0 else ""
            ev.append("Dialogue: 0,%s,%s,S,,0,0,0,,{\\an%d\\pos(%d,%d)%s}%s" % (_ass_t(st), _ass_t(en), an, x, y, pop, "".join(parts)))
            if not hl:      # sem destaque basta um evento por bloco
                ev[-1] = "Dialogue: 0,%s,%s,S,,0,0,0,,{\\an%d\\pos(%d,%d)%s}%s" % (
                    _ass_t(st), _ass_t(min(blk[-1][0] + blk[-1][1] + 0.25, nxt) - shift), an, x, y, pop, "".join(parts))
                break
    return head + "\n".join(ev) + "\n"


def build_title_ass(cfg, title, OH, y):
    """Titulo .ass: fonte, cores, caixa ou contorno, alinhamento, italico e sublinhado."""
    size = int(cfg.get("font_size", 76))
    box = bool(cfg.get("title_box", True))
    col = _ass_col(cfg.get("title_color"), "#000000")
    edge = _ass_col(cfg.get("title_box_color"), "#FFFFFF") if box else _ass_col(cfg.get("title_outline_color"), "#000000")
    an, x = _ALIGN.get(cfg.get("title_align"), _ALIGN["center"])
    txt = re.sub(r"[{}\\\r\n]", " ", str(title)).strip()
    if cfg.get("title_upper", True):
        txt = txt.upper()
    head = ASS_HEAD % (OH, 0, _ass_font(cfg.get("title_font"), "Impact"), size, col, col, edge,
                       -1 if cfg.get("title_bold") else 0, -1 if cfg.get("title_italic") else 0,
                       -1 if cfg.get("title_under") else 0, 3 if box else 1,
                       max(6, int(size * 0.2)) if box else max(3, int(size * 0.1)), 0)
    return head + "Dialogue: 0,0:00:00.00,9:59:59.00,S,,0,0,0,,{\\q0\\an%d\\pos(%d,%d)}%s\n" % (an, x, y, txt)


def fetch_transcript(url):
    """Baixa a legenda do YouTube com o yt-dlp (sem baixar o video)."""
    ytdlp = find_tool("yt-dlp")
    if not ytdlp:
        raise RuntimeError("yt-dlp não encontrado.")
    if not re.match(r"https?://", url or ""):
        raise RuntimeError("Cole o link do vídeo primeiro.")
    CACHE.mkdir(exist_ok=True)
    base = "leg_%d" % (time.time() * 1000)
    try:
        for langs in ("pt-orig,pt,pt-BR", ".*-orig", "en.*"):
            try:
                _run([ytdlp, "--no-playlist", "--skip-download", "--write-subs", "--write-auto-subs",
                                "--sub-langs", langs, "--sub-format", "json3/vtt/best", "--encoding", "utf-8",
                                "-o", str(CACHE / base) + ".%(ext)s", url],
                               capture_output=True, stdin=subprocess.DEVNULL, timeout=150, creationflags=NOWIN)
            except subprocess.TimeoutExpired:
                raise RuntimeError("O YouTube demorou demais para responder.")
            files = sorted(CACHE.glob(base + ".*"), key=lambda p: ("-orig" not in p.name, len(p.name)))
            for f in files:
                try:
                    raw = f.read_text(encoding="utf-8", errors="replace")
                    lines = parse_transcript(raw)
                    if f.suffix == ".json3":
                        save_words(url, raw)
                except Exception:
                    lines = []
                if len(lines) >= 3:
                    return lines
    finally:
        for f in CACHE.glob(base + ".*"):
            try:
                f.unlink()
            except OSError:
                pass
    raise RuntimeError("Esse vídeo não tem legenda disponível no YouTube. Use 'Importar arquivo'.")


AI_REQUEST = "Siga as instruções que estão no início do arquivo em anexo e responda só com a lista, no formato pedido."


def write_ai_files(lines, title, part_min):
    """Gera o(s) .txt com instrucoes + transcricao para enviar a uma IA."""
    out_dir = ROOT / "ia"
    out_dir.mkdir(exist_ok=True)
    lines = [l for l in lines if isinstance(l, dict) and "t" in l and l.get("text")]
    if len(lines) < 3:
        raise RuntimeError("Carregue a transcrição primeiro.")
    total = lines[-1]["t"] + 10
    parts = [lines]
    if part_min and total > part_min * 60 * 1.3:
        parts, step = [], part_min * 60
        for l in lines:
            k = int(l["t"] // step)
            while len(parts) <= k:
                parts.append([])
            parts[k].append(l)
        parts = [p for p in parts if p]
    names = []
    base = safe_name(title or "video", 60)
    for i, part in enumerate(parts):
        mins = (part[-1]["t"] - part[0]["t"]) / 60.0
        n = int(min(20, max(5, round(mins / 5.0))))
        head = [
            "INSTRUÇÕES",
            "",
            'Abaixo está a transcrição de um vídeo de gameplay: "%s".' % (title or "vídeo"),
            "Ela é uma legenda automática: pode ter palavras e nomes errados. Guie-se pelo contexto.",
            "",
            "Encontre os %d melhores momentos para virar clipes curtos (TikTok, Reels, Shorts):" % n,
            "reações fortes, momentos engraçados, sustos, vitórias, chefes derrotados, falhas,",
            "descobertas e frases marcantes.",
            "",
            "Regras:",
            "- Cada momento deve ter NO MÍNIMO 30 segundos. Não existe duração máxima:",
            "  use o tempo que o momento precisar.",
            "- Nunca corte a reação do streamer: comece um pouco antes da ação e só termine",
            "  depois que a reação e o comentário dele sobre o que aconteceu acabarem.",
            "- Cada momento deve fazer sentido sozinho, para quem não viu o resto do vídeo.",
            "- Use apenas horários que aparecem na transcrição.",
            "- Procure no trecho inteiro, não só no começo e no fim.",
            "- Responda SOMENTE com a lista, uma linha por momento, da maior nota para a menor,",
            "  exatamente neste formato:",
            "",
            "INÍCIO - FIM | TÍTULO CURTO E CHAMATIVO | NOTA de 1 a 10 | motivo em poucas palavras",
            "",
            "Exemplo:",
            "1:03:34 - 1:04:22 | Goma derrotado! | 9 | chefe derrotado com reação forte",
            "",
            "TRANSCRIÇÃO" + ("" if len(parts) == 1 else " (parte %d de %d)" % (i + 1, len(parts)))
            + " — de %s até %s" % (fmt_ts(part[0]["t"]), fmt_ts(part[-1]["t"])),
            "",
        ]
        body = ["[%s] %s" % (fmt_ts(l["t"]), str(l["text"])[:600]) for l in part]
        name = base + (" - para IA.txt" if len(parts) == 1 else " - parte %d de %d.txt" % (i + 1, len(parts)))
        (out_dir / name).write_text("\n".join(head + body) + "\n", encoding="utf-8")
        names.append(name)
    return names


# ------------------------------------------------------------ filtro FFmpeg
def _even(v):
    return max(2, int(round(v / 2.0)) * 2)


def _region(r, W, H):
    w = min(_even(r["w"] * W), W - W % 2)
    h = min(_even(r["h"] * H), H - H % 2)
    x = min(max(int(round(r["x"] * W)), 0), W - w)
    y = min(max(int(round(r["y"] * H)), 0), H - h)
    return w, h, x, y


def wrap_title(text, width=17):
    words = str(text or "").upper().split()
    lines, cur = [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines[:4]


def title_font(style="outline"):
    """Copia a fonte para a pasta cache (evita problemas de caminho no FFmpeg)."""
    dst = CACHE / ("fonte_caixa.ttf" if style == "box" else "fonte.ttf")
    if dst.exists():
        return dst.name
    CACHE.mkdir(exist_ok=True)
    win = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    bold = [win / "ariblk.ttf", win / "arialbd.ttf", win / "segoeuib.ttf",
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
            Path("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf")]
    narrow = [win / "impact.ttf", win / "arialnb.ttf",
              Path("/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf")]
    for c in (narrow + bold if style == "box" else bold):
        if c.is_file():
            shutil.copyfile(c, dst)
            if style == "box":   # guarda se a fonte e estreita, para quebrar as linhas no lugar certo
                (CACHE / "fonte_caixa.txt").write_text("1" if c.name.lower() == "impact.ttf" else "0")
            return dst.name
    return None


def _narrow_font():
    try:
        return (CACHE / "fonte_caixa.txt").read_text().strip() == "1"
    except OSError:
        return False


_DT_CAPS = []


def drawtext_new():
    """True se o FFmpeg tem o drawtext novo (caixa com altura fixa por linha)."""
    if not _DT_CAPS:
        ok = False
        ff = find_tool("ffmpeg")
        if ff:
            try:
                r = subprocess.run([ff, "-hide_banner", "-h", "filter=drawtext"], capture_output=True,
                                   stdin=subprocess.DEVNULL, timeout=20, creationflags=NOWIN)
                ok = b"y_align" in r.stdout and b"boxw" in r.stdout
            except Exception:
                ok = False
        _DT_CAPS.append(ok)
    return _DT_CAPS[0]


def logo_file(cfg):
    """Copia a logo do perfil para a pasta cache e devolve o nome (ou None)."""
    name = cfg.get("logo") or ""
    if not LOGO_RE.match(name):
        return None
    src = LOGO_DIR / name
    if not src.is_file():
        return None
    dst = CACHE / ("logo_" + name)
    if not dst.exists():
        shutil.copyfile(src, dst)
    return dst.name


def out_size(cfg):
    return OUT_SIZES.get(cfg.get("out"), OUT_SIZES["9x16"])


def _crop_x(cfg, W, cw):
    return int(min(max(round(float(cfg.get("pos_x", 0.5)) * (W - cw)), 0), W - cw))


def _fontsdir():
    """Opcao fontsdir do filtro ass (fora do Windows o FFmpeg nao enxerga Impact/Arial Black)."""
    if os.name == "nt" or not FONTS_DIR.is_dir():
        return ""
    return ":fontsdir='%s'" % str(FONTS_DIR).replace("\\", "/").replace(":", "\\:")


def build_filter(cfg, W, H, layout, title, tag, caps=None, shift=0.0):
    """Monta o filter_complex. Devolve (filtro, arquivos_temporarios)."""
    OW, OH = out_size(cfg)
    if layout == "game_only":
        layout = "fill"
    if layout not in LAYOUTS:
        layout = "cam_game"
    He = H - H % 2
    if layout == "fit":
        ar = {"4x3": 4 / 3.0, "1x1": 1.0}.get(cfg.get("fit_ar"))
        cw = W - W % 2 if not ar else min(_even(He * ar), W - W % 2)
        x = _crop_x(cfg, W, cw)
        fh = min(_even(OW * He / float(cw)), OH)
        fw = OW if fh < OH else min(_even(OH * cw / float(He)), OW)
        src = "[0:v]crop=%d:%d:%d:0,setsar=1" % (cw, He, x)
        if fh >= OH and fw >= OW:
            f = src + ",scale=%d:%d[stk]" % (OW, OH)
        elif cfg.get("bg") == "black":
            f = src + ",scale=%d:%d,pad=%d:%d:(ow-iw)/2:(oh-ih)/2:black[stk]" % (fw, fh, OW, OH)
        else:
            bw, bh = _even(OW / 4.0), _even(OH / 4.0)
            rad = 2 + int(cfg.get("blur", 50)) // 5
            f = (src + ",split=2[fg0][bg0];"
                 "[bg0]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,boxblur=%d:2,"
                 "scale=%d:%d,setsar=1[bg];"
                 "[fg0]scale=%d:%d[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2[stk]"
                 % (bw, bh, bw, bh, rad, OW, OH, fw, fh))
        gap = (OH - fh) // 2
        title_y = gap // 2 if gap >= 150 else int(OH * 0.13)
    elif layout == "fill":
        cw = min(_even(He * OW / float(OH)), W - W % 2)
        x = _crop_x(cfg, W, cw)
        f = ("[0:v]crop=%d:%d:%d:0,scale=%d:%d:force_original_aspect_ratio=increase,"
             "crop=%d:%d,setsar=1[stk]" % (cw, He, x, OW, OH, OW, OH))
        title_y = int(OH * 0.16)
    else:
        if layout == "split":
            top = OH // 4 * 2
        else:
            top = int(round(int(cfg["top_h"]) * OH / 1920.0)) // 2 * 2
            top = min(max(top, 100), OH - 100)
        bot = OH - top
        cw, ch, cx, cy = _region(cfg["cam"], W, H)
        gw, gh, gx, gy = _region(cfg["game"], W, H)
        f = ("[0:v]split=2[c][g];"
             "[c]crop=%d:%d:%d:%d,scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,setsar=1[co];"
             "[g]crop=%d:%d:%d:%d,scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,setsar=1[go];"
             "[co][go]vstack=inputs=2[stk]"
             % (cw, ch, cx, cy, OW, top, OW, top, gw, gh, gx, gy, OW, bot, OW, bot))
        title_y = top
    temps = []
    prev = "stk"
    # ---- legenda animada
    if caps:
        af = CACHE / ("legenda_%s.ass" % tag)
        af.write_text(build_ass(cfg, caps, OH, shift), encoding="utf-8")
        temps.append(af)
        f += ";[%s]ass=%s%s[cap]" % (prev, af.name, _fontsdir())
        prev = "cap"
    # ---- logo
    logo = logo_file(cfg)
    if logo:
        lw = _even(OW * int(cfg.get("logo_size", 30)) / 100.0)
        m = 40
        pos = {"tl": "%d:%d" % (m, m), "tr": "W-w-%d:%d" % (m, m), "bl": "%d:H-h-%d" % (m, m),
               "br": "W-w-%d:H-h-%d" % (m, m), "bc": "(W-w)/2:H-h-%d" % m}.get(cfg.get("logo_pos"), "%d:H-h-%d" % (m, m))
        f += (";movie=%s,scale=%d:-1,format=rgba[lg];[%s][lg]overlay=%s:eof_action=repeat:format=auto[lgo]"
              % (logo, lw, prev, pos))
        prev = "lgo"
    # ---- titulo
    if title and str(title).strip():
        pos = int(cfg.get("title_pos") or 0)
        y = int(OH * pos / 100.0) if pos else max(title_y, int(cfg.get("font_size", 76)) + 30)
        tf = CACHE / ("titulo_%s.ass" % tag)
        tf.write_text(build_title_ass(cfg, title, OH, y), encoding="utf-8")
        temps.append(tf)
        f += ";[%s]ass=%s%s[tit]" % (prev, tf.name, _fontsdir())
        prev = "tit"
    f += ";[%s]null[outv]" % prev
    return f, temps


def enc_args(cfg, encoder):
    """Opcoes de video do FFmpeg para o processador ou para a placa de video."""
    if encoder == "gpu" and ANDROID:   # codificador de hardware do Android
        mb = {"9x16": 10, "4x5": 8, "1x1": 7}.get(cfg.get("out"), 10)
        return ["-c:v", "h264_mediacodec", "-b:v", "%dM" % mb]
    if encoder == "gpu":
        q = max(10, int(cfg["crf"]) - 2)   # um pouco mais de qualidade para compensar o encoder da placa
        if os.environ.get("CLIPSTUDIO_FAKE_GPU"):   # so para testes
            return ["-c:v", "libx264", "-preset", "ultrafast", "-crf", str(q)]
        return ["-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp",
                "-qp_i", str(q), "-qp_p", str(q), "-qp_b", str(q + 2)]
    return ["-c:v", "libx264", "-preset", "veryfast" if ANDROID else "fast", "-crf", str(cfg["crf"])]


def clip_cmd(ff, src, start, span, filt, cfg, out, encoder, progress=True):
    cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % start, "-t", "%.3f" % span,
           "-i", str(src), "-filter_complex", filt, "-map", "[outv]", "-map", "0:a?"]
    cmd += enc_args(cfg, encoder)
    cmd += ["-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart"]
    if progress:
        cmd += ["-progress", "pipe:1", "-nostats"]
    return cmd + [str(out)]


def encoder_test(src, t, cfg):
    """Renderiza o mesmo trecho com o processador e com a placa, para comparar."""
    ff = find_tool("ffmpeg")
    if not ff:
        raise RuntimeError("FFmpeg não encontrado.")
    info = probe(src)
    if not info["w"]:
        raise RuntimeError("Não consegui ler o vídeo.")
    CACHE.mkdir(exist_ok=True)
    span = min(8.0, max(1.0, info["dur"]))
    t = min(max(0.0, t), max(0.0, info["dur"] - span))
    filt, temps = build_filter(cfg, info["w"], info["h"], cfg["layout"], None, "teste")
    res = {"span": span}
    for enc in ("cpu", "gpu"):
        out = CACHE / ("teste_%s.mp4" % enc)
        try:
            out.unlink()
        except OSError:
            pass
        t0 = time.time()
        try:
            r = subprocess.run(clip_cmd(ff, src, t, span, filt, cfg, out, enc, progress=False),
                               capture_output=True, stdin=subprocess.DEVNULL, timeout=600, cwd=str(CACHE), creationflags=NOWIN)
            err = r.stderr.decode("utf-8", "replace").strip().splitlines()
            ok = r.returncode == 0 and out.exists() and out.stat().st_size > 1000
        except subprocess.TimeoutExpired:
            ok, err = False, ["demorou demais"]
        res[enc] = {"ok": ok, "secs": round(time.time() - t0, 1), "size": out.stat().st_size if ok else 0,
                    "err": "" if ok else (err[-1][:300] if err else "falhou")}
    return res


# -------------------------------------------------------------------- fila
JOBS = []
JOBQ = queue.Queue()
ACTIVE_OUT = set()
LIB_REV = [1]
_job_seq = [0]


def bump():
    with LOCK:
        LIB_REV[0] += 1


class Job:
    def __init__(self, kind, label, data):
        with LOCK:
            _job_seq[0] += 1
            self.id = _job_seq[0]
        self.kind = kind
        self.label = label
        self.data = data
        self.status = "queued"   # queued running done error canceled
        self.progress = 0.0
        self.msg = "Na fila"
        self.log = []
        self.proc = None
        self.done_msg = "Concluído"
        self.result = None

    def view(self):
        v = {"id": self.id, "kind": self.kind, "label": self.label, "status": self.status,
             "progress": round(self.progress, 3), "msg": self.msg, "log": self.log[-12:]}
        if self.result is not None and self.status == "done":
            v["result"] = self.result
        return v


def add_job(kind, label, data):
    j = Job(kind, label, data)
    with LOCK:
        JOBS.append(j)
    JOBQ.put(j)
    return j


def run_proc(job, cmd, on_line, cwd=None):
    job.proc = _popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, cwd=cwd, creationflags=NOWIN)
    buf = b""
    while True:
        chunk = job.proc.stdout.read1(4096)
        if not chunk:
            break
        buf += chunk
        parts = re.split(rb"[\r\n]+", buf)
        buf = parts.pop()
        for p in parts:
            line = p.decode("utf-8", "replace").strip()
            if not line:
                continue
            if not on_line(line):
                job.log.append(line[:300])
                del job.log[:-40]
    rc = job.proc.wait()
    job.proc = None
    return rc


def do_download(job):
    d = job.data
    ytdlp = find_tool("yt-dlp")
    if not ytdlp:
        raise RuntimeError("yt-dlp não encontrado.")
    folder = DL_DIR / safe_name(d.get("video") or "Sem título", 60)
    folder.mkdir(parents=True, exist_ok=True)
    out = unique_path(folder, safe_name(d["name"]))
    ACTIVE_OUT.add(out)
    base = str(out.with_suffix("")).replace("%", "%%")
    cfg = get_cfg()
    cmd = [ytdlp, "--no-playlist", "--newline", "--encoding", "utf-8",
           "-f", "bv*[height<=%d]+ba/b" % cfg["max_height"],
           "--merge-output-format", "mp4", "-o", base + ".%(ext)s"]
    ff = find_tool("ffmpeg")
    if ff and Path(ff).parent in (ROOT, APP_DIR):
        cmd += ["--ffmpeg-location", str(Path(ff).parent)]
    span = None
    if not d.get("full"):
        span = max(1.0, float(d["end"]) - float(d["start"]))
        cmd += ["--download-sections", "*%s-%s" % (d["start"], d["end"])] + ([] if APK else ["--force-keyframes-at-cuts"])
    cmd.append(d["url"])
    re_pct = re.compile(r"\[download\]\s+([\d.]+)%")
    re_time = re.compile(r"time=(\d+):(\d+):([\d.]+)")

    def on_line(line):
        m = re_pct.search(line)
        if m:
            job.progress = float(m.group(1)) / 100.0
            job.msg = "Baixando %s%%" % m.group(1)
            return True
        m = re_time.search(line)
        if m and span:
            t = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            job.progress = min(t / span, 0.99)
            job.msg = "Baixando %d%%" % (job.progress * 100)
            return True
        if line.startswith("[Merger]") or line.startswith("[FixupM"):
            job.msg = "Finalizando…"
        return False

    try:
        job.msg = "Conectando ao YouTube…"
        stop = threading.Event()
        if APK:
            def _tick():
                t0 = time.time()
                while not stop.wait(2):
                    if job.status == "running" and job.progress < 0.01:
                        job.msg = "Baixando… %ds (pode ficar sem barra de progresso)" % (time.time() - t0)
            threading.Thread(target=_tick, daemon=True).start()
        try:
            rc = run_proc(job, cmd, on_line)
        finally:
            stop.set()
        if job.status == "canceled":
            return
        if rc != 0 or not out.exists():
            tail = next((l for l in reversed(job.log) if "ERROR" in l), job.log[-1] if job.log else "")
            raise RuntimeError("Falha no download. " + tail)
        with LOCK:
            db = get_db()
            db["downloads"][file_id(out)] = {
                "url": d["url"], "full": bool(d.get("full")),
                "start": d.get("start"), "end": d.get("end"),
                "desc": d.get("desc") or "", "video": d.get("video") or "",
                "title": d.get("title") or "", "uploader": d.get("uploader") or "",
                "at": time.time()}
            save_json(DB_FILE, db)
    finally:
        ACTIVE_OUT.discard(out)
        if job.status == "canceled" or not out.exists():
            for junk in [f for f in out.parent.iterdir() if f.name.startswith(out.stem + ".")]:
                if junk != out or job.status == "canceled":
                    try:
                        junk.unlink()
                    except OSError:
                        pass
        bump()


def do_clip(job):
    d = job.data
    ff = find_tool("ffmpeg")
    if not ff:
        raise RuntimeError("FFmpeg não encontrado. No PowerShell: winget install ffmpeg")
    src = resolve_id(d["file"], DL_SCAN)
    if not src:
        raise RuntimeError("Vídeo de origem não encontrado.")
    info = probe(src)
    if not info["w"]:
        raise RuntimeError("Não consegui ler o vídeo de origem.")
    prof = resolve_profile(d.get("profile"), d["file"])
    cfg = flat_cfg(prof)
    layout = d.get("layout") or cfg["layout"]
    proj = project_of(src)
    folder = CLIP_DIR / proj if proj else CLIP_DIR
    folder.mkdir(parents=True, exist_ok=True)
    CACHE.mkdir(exist_ok=True)
    out = unique_path(folder, safe_name(d.get("name") or src.stem))
    ACTIVE_OUT.add(out)
    start = max(0.0, float(d.get("start") or 0))
    end = float(d.get("end") or 0)
    if end <= start or end > info["dur"] + 0.5:
        end = info["dur"]
    span = max(0.5, end - start)
    caps = clean_caps(d.get("caps"))
    if not caps and d.get("auto_caps"):     # varios clipes de uma vez: busca a legenda sem revisao
        job.msg = "Buscando a legenda…"
        try:
            caps = clean_caps([[t - start, dd, w] for t, dd, w in file_words(d["file"]) if start - 0.05 <= t < end])
            if not caps:
                job.done_msg = "Concluído (sem falas neste trecho, ficou sem legenda)"
        except Exception:
            job.done_msg = "Concluído (sem legenda: o YouTube não tem a transcrição deste vídeo)"
    filt, temps = build_filter(cfg, info["w"], info["h"], layout, d.get("title"), "j%d" % job.id, caps=caps)
    encoder = cfg["encoder"]
    cmd = clip_cmd(ff, src, start, span, filt, cfg, out, encoder)
    re_t = re.compile(r"out_time=(\d+):(\d+):([\d.]+)")

    def on_line(line):
        m = re_t.match(line)
        if m:
            t = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            job.progress = min(t / span, 0.99)
            job.msg = "Montando %d%%" % (job.progress * 100)
            return True
        return bool(re.match(r"^[a-z_0-9]+=", line))  # linhas do -progress

    try:
        job.msg = "Montando clipe…"
        rc = run_proc(job, cmd, on_line, cwd=str(CACHE))
        if encoder == "gpu" and job.status != "canceled" and (rc != 0 or not out.exists()):
            # a placa de video falhou: refaz com o processador
            job.done_msg = "Concluído (a placa de vídeo falhou; usei o processador)"
            job.progress = 0.0
            job.msg = "Placa de vídeo falhou, usando o processador…"
            rc = run_proc(job, clip_cmd(ff, src, start, span, filt, cfg, out, "cpu"), on_line, cwd=str(CACHE))
        if job.status == "canceled":
            return
        if rc != 0 or not out.exists():
            raise RuntimeError("Falha ao montar o clipe. " + (job.log[-1] if job.log else ""))
        with LOCK:
            db = get_db()
            dmeta = db["downloads"].setdefault(d["file"], {})
            dmeta["profile"] = prof
            db["clips"][file_id(out)] = {"source": d["file"], "title": d.get("title") or "",
                                         "start": start, "end": end, "layout": layout, "profile": prof,
                                         "pub": {"title": dmeta.get("title") or ""}, "at": time.time()}
            save_json(DB_FILE, db)
            if dmeta.get("uploader"):
                g = get_cfg()
                g["channels"][dmeta["uploader"]] = prof
                save_json(CFG_FILE, g)
        _gallery(out)
    finally:
        ACTIVE_OUT.discard(out)
        for t in temps:
            try:
                t.unlink()
            except OSError:
                pass
        if job.status == "canceled" and out.exists():
            try:
                out.unlink()
            except OSError:
                pass
        bump()


def pick_peaks(levels, n):
    """Acha os n maiores picos de volume (em dB acima do normal ao redor)."""
    L = len(levels)
    sm = [sum(levels[max(0, i - 1):i + 2]) / len(levels[max(0, i - 1):i + 2]) for i in range(L)]
    exc = []
    for i in range(L):
        w = sorted(sm[max(0, i - 90):i + 91])
        exc.append(sm[i] - w[len(w) // 2])
    chosen = []
    for i in sorted(range(5, L), key=lambda k: -exc[k]):
        if exc[i] < 3 or len(chosen) >= n:
            break
        if all(abs(i - j) >= 50 for j in chosen):
            chosen.append(i)
    items = []
    for i in sorted(chosen):
        start = max(0, i - 15)
        end = min(L, max(i + 20, start + 32))
        items.append({"start": start, "end": end, "title": "", "score": round(min(10.0, 5 + exc[i] / 3.0), 1),
                      "desc": "Pico de áudio em %s (+%d dB acima do normal). Confira o início e o fim." % (fmt_ts(i), round(exc[i]))})
    return items


def do_analyze(job):
    d = job.data
    ff = find_tool("ffmpeg")
    if not ff:
        raise RuntimeError("FFmpeg não encontrado.")
    CACHE.mkdir(exist_ok=True)
    src, tmp = None, None
    for fid, m in get_db()["downloads"].items():   # ja tem o video inteiro baixado?
        if m.get("full") and m.get("url") == d["url"]:
            src = resolve_id(fid, DL_SCAN) or src
    base = "aud_%d_%d" % (os.getpid(), job.id)
    try:
        if not src:
            ytdlp = find_tool("yt-dlp")
            if not ytdlp:
                raise RuntimeError("yt-dlp não encontrado.")
            re_pct = re.compile(r"\[download\]\s+([\d.]+)%")

            def on_line(line):
                m = re_pct.search(line)
                if m:
                    job.progress = float(m.group(1)) / 100.0 * 0.6
                    job.msg = "Baixando só o áudio %s%%" % m.group(1)
                return bool(m)

            job.msg = "Baixando só o áudio…"
            rc = run_proc(job, [ytdlp, "--no-playlist", "--newline", "--encoding", "utf-8",
                                "-f", "ba[abr<=80]/ba/b[height<=360]/b", "-o", str(CACHE / base) + ".%(ext)s", d["url"]], on_line)
            if job.status == "canceled":
                return
            files = [f for f in CACHE.glob(base + ".*") if f.suffix != ".part"]
            if rc != 0 or not files:
                raise RuntimeError("Não consegui baixar o áudio. " + (job.log[-1] if job.log else ""))
            src = tmp = files[0]
        job.msg = "Analisando o áudio…"
        dur = float(d.get("dur") or 0) or probe(src)["dur"] or 1.0
        job.proc = subprocess.Popen([ff, "-v", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", "4000", "-f", "s16le", "-"],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, creationflags=NOWIN)
        levels = []
        while True:
            buf = job.proc.stdout.read(8000)   # 1 segundo de audio
            if len(buf) < 8000:
                break
            a = array.array("h")
            a.frombytes(buf)
            levels.append(20 * math.log10(max(math.sqrt(sum(x * x for x in a) / len(a)), 1.0)))
            if len(levels) % 20 == 0:
                job.progress = 0.6 + 0.4 * min(len(levels) / dur, 1.0)
                job.msg = "Analisando o áudio %d%%" % (min(len(levels) / dur, 1.0) * 100)
        job.proc.wait()
        job.proc = None
        if job.status == "canceled":
            return
        if len(levels) < 60:
            raise RuntimeError("Áudio curto demais para analisar.")
        items = pick_peaks(levels, int(min(20, max(8, round(len(levels) / 360.0)))))
        job.result = {"items": items}
        job.done_msg = "%d trecho(s) sugeridos na aba Momentos" % len(items) if items else "Nenhum pico de áudio claro neste vídeo"
    finally:
        for f in CACHE.glob(base + ".*"):
            try:
                f.unlink()
            except OSError:
                pass


def worker():
    while True:
        job = JOBQ.get()
        if job.status != "queued":
            continue
        job.status = "running"
        try:
            {"download": do_download, "analyze": do_analyze}.get(job.kind, do_clip)(job)
            if job.status == "running":
                job.status = "done"
                job.progress = 1.0
                job.msg = job.done_msg
        except Exception as e:  # noqa
            if job.status != "canceled":
                job.status = "error"
                job.msg = str(e)[:400]
        bump()


# -------------------------------------------------------------- biblioteca
def fill_missing_titles():
    """Descobre no YouTube o nome dos videos de downloads antigos e organiza em projetos."""
    try:
        ytdlp = find_tool("yt-dlp")
        db = get_db()
        known = {m.get("url") for m in db["downloads"].values() if m.get("video")}
        urls = {m.get("url") for fid, m in db["downloads"].items()
                if m.get("url") and not m.get("video") and (ROOT / fid).is_file()} - known
        if not ytdlp or not urls:
            return
        found = {}
        for url in list(urls)[:20]:
            try:
                r = _run([ytdlp, "--no-playlist", "--skip-download", "--encoding", "utf-8",
                                    "--print", "%(title)s", "--print", "%(uploader)s", url],
                                   capture_output=True, stdin=subprocess.DEVNULL, timeout=90, creationflags=NOWIN)
                out = r.stdout.decode("utf-8", "replace").strip().splitlines()
                if r.returncode == 0 and out and out[0].strip():
                    found[url] = (out[0].strip(), out[1].strip() if len(out) > 1 else "")
            except Exception:
                pass
        if not found:
            return
        with LOCK:
            db = get_db()
            for m in db["downloads"].values():
                if m.get("url") in found and not m.get("video"):
                    m["video"] = found[m["url"]][0]
                    m.setdefault("uploader", found[m["url"]][1])
            save_json(DB_FILE, db)
        migrate_projects()
        bump()
    except Exception as e:  # noqa
        print("Aviso: nao consegui buscar os nomes dos videos:", e)


def _list(scan):
    seen, out = set(), []
    bases = (DL_DIR, CLIP_DIR)
    for d in scan:
        if not d.is_dir():
            continue
        entries = list(d.iterdir())
        if d in bases:
            for sub in [e for e in entries if e.is_dir()]:
                try:
                    entries += list(sub.iterdir())
                except OSError:
                    pass
        for p in entries:
            if p.suffix.lower() not in VIDEO_EXT or not p.is_file():
                continue
            if p in ACTIVE_OUT or re.search(r"\.(f\d+|temp|part)\.", p.name) or p in seen:
                continue
            seen.add(p)
            out.append(p)
    return out


def library():
    db = get_db()
    cfg = get_cfg()
    clips = []
    used = {}
    for p in _list(CLIP_SCAN):
        fid = file_id(p)
        meta = db["clips"].get(fid, {})
        info = probe(p)
        st = p.stat()
        if meta.get("source"):
            used[meta["source"]] = used.get(meta["source"], 0) + 1
        clips.append({"id": fid, "name": p.stem, "dur": info["dur"], "w": info["w"], "h": info["h"],
                      "size": st.st_size, "mtime": st.st_mtime, "source": meta.get("source", ""),
                      "title": meta.get("title", ""), "pub": pub_view(meta, cfg), "project": project_of(p)})
    downs = []
    for p in _list(DL_SCAN):
        fid = file_id(p)
        meta = db["downloads"].get(fid, {})
        info = probe(p)
        st = p.stat()
        downs.append({"id": fid, "name": p.stem, "dur": info["dur"], "w": info["w"], "h": info["h"],
                      "size": st.st_size, "mtime": st.st_mtime, "clips": used.get(fid, 0),
                      "desc": meta.get("desc", ""), "video": meta.get("video", ""),
                      "full": bool(meta.get("full")), "url": meta.get("url", ""),
                      "title": meta.get("title", ""), "uploader": meta.get("uploader", ""),
                      "profile": resolve_profile(None, fid, db, cfg), "project": project_of(p)})
    downs.sort(key=lambda x: -x["mtime"])
    clips.sort(key=lambda x: -x["mtime"])
    return {"downloads": downs, "clips": clips, "rev": LIB_REV[0], "config": cfg, "ai_request": AI_REQUEST,
            "tools": {"ytdlp": bool(find_tool("yt-dlp")), "ffmpeg": bool(find_tool("ffmpeg"))},
            "inbox": INBOX.is_file(), "root": str(ROOT)}


def pub_view(meta, cfg):
    p = dict(meta.get("pub") or {})
    out = {"title": str(p.get("title") or ""), "desc": str(p.get("desc") or ""),
           "tags": str(p["tags"]) if "tags" in p else cfg["tags"]}
    for k in ("yt", "tt", "ig"):
        out[k] = bool(p.get(k))
    return out


def make_image(src, t, vf_or_filter, complex_=False, cache_key=None, quality="3"):
    """Extrai um quadro (com filtro opcional) e devolve bytes JPEG."""
    ff = find_tool("ffmpeg")
    if not ff:
        return None
    CACHE.mkdir(exist_ok=True)
    if cache_key:
        out = CACHE / ("img_%s.jpg" % cache_key)
        if out.exists():
            return out.read_bytes()
    else:
        out = CACHE / ("tmp_%d_%d.jpg" % (threading.get_ident(), int(time.time() * 1000) % 100000))
    cmd = [ff, "-y", "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % max(0.0, t), "-i", str(src)]
    if complex_:
        cmd += ["-filter_complex", vf_or_filter, "-map", "[outv]"]
    elif vf_or_filter:
        cmd += ["-vf", vf_or_filter]
    cmd += ["-frames:v", "1", "-q:v", quality, str(out)]
    try:
        subprocess.run(cmd, capture_output=True, stdin=subprocess.DEVNULL, timeout=60, cwd=str(CACHE), creationflags=NOWIN)
        data = out.read_bytes() if out.exists() else None
    except Exception:
        data = None
    if not cache_key:
        try:
            out.unlink()
        except OSError:
            pass
    return data


# ------------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ClipStudio"

    def log_message(self, *a):
        pass

    # -- respostas
    def send_bytes(self, data, ctype, code=200, cache=False):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def send_json(self, obj, code=200):
        self.send_bytes(json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", code)

    def fail(self, msg, code=400):
        self.send_json({"error": msg}, code)

    def send_media(self, path):
        size = path.stat().st_size
        start, end = 0, size - 1
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range") or "")
        code = 200
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                start = int(m.group(1))
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
            else:
                start = max(0, size - int(m.group(2)))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            code = 206
        ctype = {".mp4": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska",
                 ".mov": "video/quicktime"}.get(path.suffix.lower(), "application/octet-stream")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        left = end - start + 1
        try:
            with open(path, "rb") as f:
                f.seek(start)
                while left > 0:
                    chunk = f.read(min(262144, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (ConnectionError, OSError):
            self.close_connection = True

    # -- seguranca: so aceita chamadas da propria janela do programa
    def allowed(self):
        host = (self.headers.get("Host") or "").lower()
        ok_hosts = ("127.0.0.1:%d" % PORT, "localhost:%d" % PORT)
        if host not in ok_hosts:
            return False
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in tuple("http://" + h for h in ok_hosts):
            return False
        return True

    def do_GET(self):
        if not self.allowed():
            return self.fail("acesso negado", 403)
        LAST_SEEN[0] = time.time()
        u = urllib.parse.urlsplit(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            self.route_get(u.path, q)
        except (ConnectionError, BrokenPipeError):
            self.close_connection = True
        except Exception as e:  # noqa
            self.fail("erro interno: %s" % e, 500)

    do_HEAD = do_GET

    def route_get(self, path, q):
        if path in ("/", "/index.html"):
            return self.send_bytes((RES_DIR / "ui.html").read_bytes(), "text/html; charset=utf-8")
        if path in ("/favicon.ico", "/icone.png"):
            f = RES_DIR / "icone.png"
            return self.send_bytes(f.read_bytes(), "image/png", cache=True) if f.is_file() else self.fail("sem icone", 404)
        if path == "/logo":
            n = q.get("n") or ""
            f = LOGO_DIR / n
            if not LOGO_RE.match(n) or not f.is_file():
                return self.fail("sem logo", 404)
            ct = {"png": "image/png", "jpg": "image/jpeg", "webp": "image/webp"}[n.rsplit(".", 1)[1]]
            return self.send_bytes(f.read_bytes(), ct, cache=True)
        if path == "/api/ping":
            return self.send_json({"app": "clipstudio"})
        if path == "/api/ytlog":   # diagnostico: abra http://127.0.0.1:8765/api/ytlog no navegador do celular
            out = []
            for n in ("erro.log", "ytdlp_update.log", "ytdlp.log"):
                f = APP_DIR / n
                if f.is_file():
                    out.append("=== %s ===\n%s" % (n, f.read_text(encoding="utf-8", errors="replace")[-6000:]))
            return self.send_bytes(("\n".join(out) or "sem logs").encode("utf-8"), "text/plain; charset=utf-8")
        if path == "/api/jobs":
            with LOCK:
                return self.send_json({"jobs": [j.view() for j in JOBS], "rev": LIB_REV[0], "boot": BOOT})
        if path == "/api/library":
            return self.send_json(library())
        if path == "/api/inbox":
            if not INBOX.is_file():
                return self.fail("Nenhuma lista nova.", 404)
            return self.send_json(parse_moments(INBOX.read_text(encoding="utf-8", errors="replace")))
        if path == "/cmp":
            f = CACHE / ("teste_%s.mp4" % ("gpu" if q.get("k") == "gpu" else "cpu"))
            return self.send_media(f) if f.is_file() else self.fail("sem teste", 404)
        if path in ("/media", "/thumb", "/frame", "/preview"):
            p = resolve_id(q.get("f"), DL_SCAN + CLIP_SCAN)
            if not p:
                return self.fail("arquivo não encontrado", 404)
            if path == "/media":
                return self.send_media(p)
            info = probe(p)
            t = float(q.get("t") or 0)
            if path == "/thumb":
                st = p.stat()
                key = hashlib.md5(("%s|%d|%d" % (p, st.st_mtime_ns, st.st_size)).encode()).hexdigest()[:16]
                data = make_image(p, min(info["dur"] * 0.3, 20), "scale=-2:270", cache_key=key, quality="5")
                return self.send_bytes(data, "image/jpeg", cache=True) if data else self.fail("sem miniatura", 500)
            if path == "/frame":
                data = make_image(p, t, None)
                return self.send_bytes(data, "image/jpeg") if data else self.fail("sem quadro", 500)
            cfg = flat_cfg(resolve_profile(q.get("profile"), q.get("f")))
            if q.get("cfg"):
                cfg.update(clean_profile(json.loads(q["cfg"])))
            caps, shift = None, 0.0
            if q.get("capdemo"):
                caps = [[-1, 1, "essa"], [0, 5, "legenda"], [5, 1, "muda"], [6, 1, "de"], [7, 1, "cor"]][:int(cfg.get("cap_words", 4)) + 1]
            elif q.get("caps"):
                try:
                    caps, shift = clean_caps(json.loads(q["caps"])), float(q.get("cs") or 0)
                except Exception:
                    caps = None
            filt, temps = build_filter(cfg, info["w"], info["h"], q.get("layout") or cfg["layout"],
                                       q.get("title"), "p%d" % threading.get_ident(), caps=caps, shift=shift)
            data = make_image(p, t, filt.replace("[outv]", "[pre]") + ";[pre]scale=540:-2[outv]", complex_=True)
            for tf in temps:
                try:
                    tf.unlink()
                except OSError:
                    pass
            return self.send_bytes(data, "image/jpeg") if data else self.fail("falha na prévia", 500)
        self.fail("não encontrado", 404)

    def do_POST(self):
        if not self.allowed():
            return self.fail("acesso negado", 403)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}
            self.route_post(urllib.parse.urlsplit(self.path).path, body)
        except RuntimeError as e:
            self.fail(str(e))
        except Exception as e:  # noqa
            self.fail("erro: %s" % e, 500)

    def route_post(self, path, b):
        if path == "/api/parse":
            return self.send_json(parse_moments(b.get("text", "")))
        if path == "/api/info":
            return self.api_info(b)
        if path == "/api/download":
            return self.api_download(b)
        if path == "/api/clip":
            n = 0
            for it in b.get("items") or []:
                src = resolve_id(it.get("file"), DL_SCAN)
                if not src:
                    continue
                add_job("clip", "Clipe: " + (it.get("name") or src.stem), it)
                n += 1
            return self.send_json({"queued": n})
        if path == "/api/cancel":
            with LOCK:
                for j in JOBS:
                    if j.id == b.get("id") and j.status in ("queued", "running"):
                        j.status = "canceled"
                        j.msg = "Cancelado"
                        if j.proc:
                            try:
                                j.proc.terminate()
                            except Exception:
                                pass
            return self.send_json({"ok": True})
        if path == "/api/clear_jobs":
            with LOCK:
                JOBS[:] = [j for j in JOBS if j.status in ("queued", "running")]
            return self.send_json({"ok": True})
        if path == "/api/transcript":
            lines = parse_transcript(b["text"]) if b.get("text") else fetch_transcript((b.get("url") or "").strip())
            lines = merge_blocks(lines)
            if len(lines) < 3:
                return self.fail("Não encontrei falas com horário nesse arquivo. Exporte em .srt ou em texto com horários.")
            return self.send_json({"lines": lines})
        if path == "/api/captions":
            try:
                return self.send_json({"words": file_words(b.get("file"))})
            except RuntimeError as e:
                return self.fail(str(e))
        if path == "/api/analyze":
            url = (b.get("url") or "").strip()
            if not re.match(r"https?://", url):
                return self.fail("Cole o link do vídeo primeiro.")
            add_job("analyze", "Sugerir trechos: " + (b.get("video") or url), {"url": url, "dur": b.get("dur") or 0})
            return self.send_json({"queued": 1})
        if path == "/api/enctest":
            src = resolve_id(b.get("file"), DL_SCAN)
            if not src:
                return self.fail("Escolha um vídeo baixado para o teste.", 404)
            cfg = flat_cfg(resolve_profile(b.get("profile"), b.get("file")))
            return self.send_json(encoder_test(src, float(b.get("t") or 0), cfg))
        if path == "/api/aifile":
            names = write_ai_files(b.get("lines") or [], b.get("title") or "", int(b.get("part_min") or 0))
            return self.send_json({"files": names})
        if path == "/api/clipmeta":
            p = resolve_id(b.get("file"), CLIP_SCAN)
            if not p:
                return self.fail("clipe não encontrado", 404)
            src = b.get("pub") or {}
            pub = {"title": str(src.get("title") or "")[:150], "desc": str(src.get("desc") or "")[:3000],
                   "tags": str(src.get("tags") or "")[:500]}
            for k in ("yt", "tt", "ig"):
                pub[k] = bool(src.get(k))
            with LOCK:
                db = get_db()
                db["clips"].setdefault(file_id(p), {})["pub"] = pub
                save_json(DB_FILE, db)
            return self.send_json({"ok": True})
        if path == "/api/openurl":
            url = {"yt": "https://www.youtube.com/upload", "tt": "https://www.tiktok.com/tiktokstudio/upload",
                   "ig": "https://www.instagram.com/"}.get(b.get("site"))
            if not url:
                return self.fail("site desconhecido")
            if APK:
                _bridge().openUrl(url)
            else:
                webbrowser.open(url)
            return self.send_json({"ok": True})
        if path == "/api/logo":
            import base64
            raw = str(b.get("data") or "")
            try:
                data = base64.b64decode(raw.split(",", 1)[-1], validate=False)
            except Exception:
                return self.fail("Imagem inválida.")
            if data[:8] == b"\x89PNG\r\n\x1a\n":
                ext = "png"
            elif data[:3] == b"\xff\xd8\xff":
                ext = "jpg"
            elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
                ext = "webp"
            else:
                return self.fail("Use uma imagem PNG (de preferência com fundo transparente), JPG ou WebP.")
            if len(data) > 8 * 1024 * 1024:
                return self.fail("Imagem muito grande (máximo 8 MB).")
            LOGO_DIR.mkdir(parents=True, exist_ok=True)
            name = hashlib.md5(data).hexdigest()[:16] + "." + ext
            (LOGO_DIR / name).write_bytes(data)
            return self.send_json({"logo": name})
        if path in ("/api/config", "/api/profile_delete", "/api/config_reset"):
            with LOCK:
                g = get_cfg()
                name = safe_name(b.get("profile") or g["active"], 40)
                if path == "/api/config":
                    if isinstance(b.get("data"), dict):
                        g["profiles"][name] = clean_profile(b["data"], g["profiles"].get(name))
                        g["active"] = name
                    try:
                        if "crf" in b:
                            g["crf"] = int(min(max(int(b["crf"]), 14), 32))
                        if "max_height" in b and int(b["max_height"]) in (720, 1080, 1440, 2160):
                            g["max_height"] = int(b["max_height"])
                    except (TypeError, ValueError):
                        pass
                    if "tags" in b:
                        g["tags"] = str(b["tags"])[:500]
                    if b.get("encoder") in ("cpu", "gpu"):
                        g["encoder"] = b["encoder"]
                elif path == "/api/config_reset":
                    g["profiles"][name] = json.loads(json.dumps(DEFAULT_PROFILE))
                elif name in g["profiles"]:
                    if len(g["profiles"]) < 2:
                        return self.fail("Precisa existir pelo menos um perfil.")
                    del g["profiles"][name]
                    g["channels"] = {c: p for c, p in g["channels"].items() if p != name}
                    if g["active"] == name:
                        g["active"] = next(iter(g["profiles"]))
                save_json(CFG_FILE, g)
            bump()
            return self.send_json(get_cfg())
        if path in ("/api/delete", "/api/rename", "/api/open"):
            return self.api_file(path, b)
        self.fail("não encontrado", 404)

    def api_info(self, b):
        url = (b.get("url") or "").strip()
        ytdlp = find_tool("yt-dlp")
        if not ytdlp:
            return self.fail("yt-dlp não encontrado.")
        if not re.match(r"https?://", url):
            return self.fail("Cole um link válido.")
        try:
            r = _run([ytdlp, "--no-playlist", "--skip-download", "--encoding", "utf-8",
                                "--print", "%(title)s", "--print", "%(duration)s", "--print", "%(uploader)s", url],
                               capture_output=True, stdin=subprocess.DEVNULL, timeout=90, creationflags=NOWIN)
        except subprocess.TimeoutExpired:
            return self.fail("O YouTube demorou demais para responder.")
        lines = r.stdout.decode("utf-8", "replace").strip().splitlines()
        if r.returncode != 0 or len(lines) < 2:
            err = r.stderr.decode("utf-8", "replace").strip().splitlines()
            return self.fail("Não consegui ler o vídeo. " + (err[-1] if err else ""))
        try:
            dur = float(lines[1])
        except ValueError:
            dur = 0
        return self.send_json({"title": lines[0], "dur": dur, "uploader": lines[2] if len(lines) > 2 else ""})

    def api_download(self, b):
        url = (b.get("url") or "").strip()
        if not re.match(r"https?://", url):
            return self.fail("Cole o link do vídeo primeiro.")
        video = b.get("video") or ""
        n = 0
        if b.get("full"):
            add_job("download", "Vídeo inteiro: " + (video or url),
                    {"url": url, "full": True, "name": video or "video", "video": video,
                     "uploader": b.get("uploader") or ""})
            n = 1
        for it in b.get("items") or []:
            try:
                s, e = float(it["start"]), float(it["end"])
            except Exception:
                continue
            if e <= s:
                continue
            name = it.get("name") or it.get("desc") or "trecho"
            label = "%s (%s–%s)" % (name, fmt_ts(s), fmt_ts(e))
            add_job("download", "Trecho: " + label,
                    {"url": url, "start": s, "end": e, "video": video, "desc": it.get("desc") or "",
                     "title": it.get("title") or "", "uploader": b.get("uploader") or "",
                     "name": "%s %s" % (safe_name(name, 50), ("%dh%02dm%02ds" % (s // 3600, s % 3600 // 60, s % 60) if s >= 3600 else "%dm%02ds" % (s // 60, s % 60)))})
            n += 1
        return self.send_json({"queued": n})

    def api_file(self, path, b):
        p = resolve_id(b.get("file"), DL_SCAN + CLIP_SCAN)
        if path == "/api/open":
            target = p if p else ROOT / (b.get("dir") if b.get("dir") in ("baixados", "clipes", "ia") else "")
            if not p:
                target.mkdir(exist_ok=True)
                sub = target / safe_name(b.get("project") or "", 60)
                if b.get("project") and b.get("dir") in ("baixados", "clipes") and sub.is_dir():
                    target = sub
            try:
                if APK:
                    if p:
                        _bridge().openFile(str(p))
                    where = {"clipes": "Galeria > Filmes > ClipStudio"}.get(b.get("dir"), str(p.parent if p else target))
                    return self.send_json({"ok": True, "msg": "Arquivos em: %s" % where})
                if ANDROID:
                    op = shutil.which("termux-open")
                    if not (p and op):
                        return self.send_json({"ok": True, "msg": "Arquivos em: %s" % (p.parent if p else target)})
                    subprocess.Popen([op, str(p)])
                elif os.name == "nt":
                    if p:
                        subprocess.Popen(["explorer", "/select,", str(p)])
                    else:
                        os.startfile(str(target))  # noqa
                else:
                    subprocess.Popen(["xdg-open", str(target.parent if p else target)])
            except Exception as e:  # noqa
                return self.fail(str(e))
            return self.send_json({"ok": True})
        if path == "/api/delete" and isinstance(b.get("files"), list):
            n, errs = 0, []
            with LOCK:
                db = get_db()
                for f in b["files"][:2000]:
                    fp = resolve_id(f, DL_SCAN + CLIP_SCAN)
                    if not fp:
                        continue
                    try:
                        fp.unlink()
                    except OSError:
                        errs.append(fp.name)
                        continue
                    n += 1
                    db["downloads"].pop(file_id(fp), None)
                    db["clips"].pop(file_id(fp), None)
                    if project_of(fp):
                        try:
                            fp.parent.rmdir()   # so apaga a pasta se ficou vazia
                        except OSError:
                            pass
                save_json(DB_FILE, db)
            bump()
            return self.send_json({"deleted": n, "errors": errs})
        if not p:
            return self.fail("arquivo não encontrado", 404)
        fid = file_id(p)
        with LOCK:
            db = get_db()
            if path == "/api/delete":
                try:
                    p.unlink()
                except OSError as e:
                    return self.fail("Não consegui apagar (arquivo em uso?). %s" % e)
                db["downloads"].pop(fid, None)
                db["clips"].pop(fid, None)
            else:
                new = p.with_name(safe_name(b.get("name")) + p.suffix)
                if new.exists():
                    return self.fail("Já existe um arquivo com esse nome.")
                try:
                    p.rename(new)
                except OSError as e:
                    return self.fail("Não consegui renomear (arquivo em uso?). %s" % e)
                nid = file_id(new)
                for tbl in ("downloads", "clips"):
                    if fid in db[tbl]:
                        db[tbl][nid] = db[tbl].pop(fid)
                for c in db["clips"].values():
                    if c.get("source") == fid:
                        c["source"] = nid
            save_json(DB_FILE, db)
        bump()
        return self.send_json({"ok": True})


# ------------------------------------------------------------------- main
def find_browser():
    """Procura Edge, Chrome ou Brave para abrir em janela propria."""
    env = os.environ
    if env.get("CLIPSTUDIO_BROWSER"):
        return env["CLIPSTUDIO_BROWSER"]
    bases = [env.get("PROGRAMFILES(X86)"), env.get("PROGRAMFILES"), env.get("LOCALAPPDATA")]
    rels = ["Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe",
            "BraveSoftware/Brave-Browser/Application/brave.exe"]
    for rel in rels:
        for b in bases:
            if b and (Path(b) / rel).is_file():
                return str(Path(b) / rel)
    return None


def open_window(url):
    """Abre a janela do programa. Devolve o processo da janela, se der para acompanhar."""
    if os.environ.get("CLIPSTUDIO_NO_BROWSER"):
        return None
    if ANDROID:
        op = shutil.which("termux-open-url")
        if op:
            try:
                subprocess.Popen([op, url], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass
        return None
    exe = find_browser()
    if exe:
        try:  # janela propria, sem barra de navegador, com perfil separado (assim da para saber quando fechou)
            return subprocess.Popen([exe, "--app=" + url, "--user-data-dir=" + str(APP_DIR / "janela"),
                                     "--no-first-run", "--no-default-browser-check", "--window-size=1280,860"],
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    webbrowser.open(url)
    return None


def busy():
    with LOCK:
        return any(j.status in ("queued", "running") for j in JOBS)


def wait_until_closed(win):
    """Espera o usuario fechar a janela (e a fila terminar) para encerrar o programa."""
    if os.environ.get("CLIPSTUDIO_NO_BROWSER") or ANDROID:   # no celular o servidor fica de pe ate Ctrl+C
        while True:
            time.sleep(3600)
    t0 = time.time()
    if win is not None:
        win.wait()
        if time.time() - t0 < 6:
            win = None   # o navegador repassou a janela para outro processo: usa o plano B
    if win is None:
        LAST_SEEN[0] = time.time()
        while time.time() - LAST_SEEN[0] < 150:   # a janela aberta fala com o programa a cada segundo
            time.sleep(3)
    while busy():   # termina os downloads e clipes que estavam na fila
        time.sleep(1)


def already_running(url):
    try:
        with urllib.request.urlopen(url + "/api/ping", timeout=2) as r:
            return b"clipstudio" in r.read()
    except Exception:
        return False


def main():
    url = "http://127.0.0.1:%d" % PORT
    ROOT.mkdir(parents=True, exist_ok=True)
    for d in (APP_DIR, DL_DIR, CLIP_DIR, CACHE):
        d.mkdir(exist_ok=True)
    try:
        migrate_projects()
    except Exception as e:  # noqa
        print("Aviso: nao consegui organizar os projetos:", e)
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        if already_running(url):
            print("O ClipStudio ja esta aberto. Abrindo a janela...")
            open_window(url)
            return
        raise RuntimeError("A porta %d esta ocupada por outro programa." % PORT)
    srv.daemon_threads = True
    threading.Thread(target=worker, daemon=True).start()
    threading.Thread(target=fill_missing_titles, daemon=True).start()
    print("=" * 56)
    print("  ClipStudio rodando em  %s" % url)
    print("  Pasta: %s" % ROOT)
    print("  yt-dlp: %s" % (find_tool("yt-dlp") or "NAO ENCONTRADO"))
    print("  ffmpeg: %s" % (find_tool("ffmpeg") or "NAO ENCONTRADO"))
    print("  Para encerrar: Ctrl+C aqui no Termux." if ANDROID else "  O programa encerra sozinho quando voce fecha a janela dele.")
    print("=" * 56)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        wait_until_closed(open_window(url))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        msg = traceback.format_exc()
        print(msg)
        try:
            APP_DIR.mkdir(exist_ok=True)
            (APP_DIR / "erro.log").write_text(msg, encoding="utf-8")
            if os.name == "nt":
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, "O ClipStudio deu erro ao abrir.\nOs detalhes estao em clipstudio\\erro.log\n\n" + msg[-600:], "ClipStudio", 0x10)
        except Exception:
            pass
