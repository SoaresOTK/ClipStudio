package com.clipstudio.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var splash: TextView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val pickCode = 42
    @Volatile private var alive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        startForegroundService(Intent(this, ServerService::class.java))

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F1115"))
            fitsSystemWindows = true
        }
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0F1115"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    if (r.url.host == "127.0.0.1") return false
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, r.url)) }
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
                ): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = cb
                    return try {
                        startActivityForResult(params.createIntent(), pickCode)
                        true
                    } catch (e: Exception) {
                        fileCb = null
                        false
                    }
                }
            }
        }
        splash = TextView(this).apply {
            setTextColor(Color.parseColor("#C9CED8"))
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            text = "Iniciando…"
        }
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(splash, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        waitForServer()
    }

    private fun waitForServer() {
        Thread {
            val url = "http://127.0.0.1:${ServerService.PORT}"
            while (alive) {
                runOnUiThread { splash.text = ServerService.status }
                val ok = try {
                    val c = URL("$url/api/ping").openConnection() as HttpURLConnection
                    c.connectTimeout = 800
                    c.readTimeout = 800
                    c.responseCode == 200
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    runOnUiThread {
                        splash.visibility = android.view.View.GONE
                        web.loadUrl(url)
                    }
                    return@Thread
                }
                Thread.sleep(700)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == pickCode) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)   // nao encerra o servidor
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
    }
}
