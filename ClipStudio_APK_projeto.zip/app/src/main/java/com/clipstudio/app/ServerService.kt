package com.clipstudio.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import android.system.Os
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

/** Mantem o servidor Python (app.py) vivo, mesmo com a tela apagada, durante downloads e renders. */
class ServerService : Service() {
    companion object {
        const val PORT = 8765
        @Volatile var status = "Iniciando…"
        @Volatile private var started = false
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("srv", "ClipStudio", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, "srv")
            .setContentTitle("ClipStudio")
            .setContentText("Rodando em segundo plano")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (!started) {
            started = true
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ClipStudio:render").apply { acquire() }
            Thread({ boot() }, "clipstudio-boot").start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    private fun boot() {
        val appDir = File(filesDir, "clipstudio")
        try {
            status = "Preparando arquivos…"
            copyAssets(appDir)

            status = "Preparando yt-dlp e FFmpeg (a primeira vez demora)…"
            Bridge.initTools(applicationContext)
            val ff = Bridge.findFfmpeg()

            val root = File(getExternalFilesDir(null) ?: filesDir, "ClipStudio").apply { mkdirs() }
            Os.setenv("CLIPSTUDIO_ANDROID", "1", true)
            Os.setenv("CLIPSTUDIO_APPDIR", appDir.absolutePath, true)
            Os.setenv("CLIPSTUDIO_ROOT", root.absolutePath, true)
            Os.setenv("CLIPSTUDIO_PORT", PORT.toString(), true)
            Os.setenv("CLIPSTUDIO_NO_BROWSER", "1", true)
            if (ff != null) {
                Os.setenv("CLIPSTUDIO_FFMPEG", ff[0], true)
                File(File(ff[0]).parentFile, "libffprobe.so").takeIf { it.exists() }?.let { Os.setenv("CLIPSTUDIO_FFPROBE", it.absolutePath, true) }
                val old = System.getenv("LD_LIBRARY_PATH")
                Os.setenv("LD_LIBRARY_PATH", ff[1] + (if (old.isNullOrEmpty()) "" else ":$old"), true)
            }

            status = "Iniciando o ClipStudio…"
            if (!Python.isStarted()) Python.start(AndroidPlatform(this))
            Thread({ Bridge.updateYtdlp().let { appDir.resolve("ytdlp_update.log").writeText(it) } }, "ytdlp-update").start()
            Python.getInstance().getModule("clipstudio_app").callAttr("main")   // bloqueia enquanto o servidor roda
        } catch (e: Throwable) {
            status = "Erro ao iniciar: " + (e.message ?: e.toString())
            try {
                appDir.mkdirs()
                File(appDir, "erro.log").writeText(e.stackTraceToString())
            } catch (ignored: Throwable) {
            }
        }
    }

    private fun copyAssets(dest: File) {
        dest.mkdirs()
        val stamp = packageManager.getPackageInfo(packageName, 0).lastUpdateTime.toString()
        val mark = File(dest, ".versao")
        if (mark.exists() && mark.readText() == stamp && File(dest, "ui.html").exists()) return
        copyAssetDir("clipstudio", dest)
        mark.writeText(stamp)
    }

    private fun copyAssetDir(assetPath: String, dest: File) {
        val list = assets.list(assetPath) ?: return
        if (list.isEmpty()) {   // e um arquivo
            dest.parentFile?.mkdirs()
            assets.open(assetPath).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            return
        }
        dest.mkdirs()
        for (name in list) copyAssetDir("$assetPath/$name", File(dest, name))
    }
}
