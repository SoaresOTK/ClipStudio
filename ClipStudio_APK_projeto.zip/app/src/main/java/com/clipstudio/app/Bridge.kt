package com.clipstudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** Funcoes Kotlin que o Python (app.py) chama: yt-dlp, FFmpeg, Galeria, abrir arquivos e links. */
object Bridge {
    lateinit var ctx: Context

    /** Inicializa o yt-dlp e o FFmpeg da biblioteca (a primeira vez descompacta os arquivos). */
    fun initTools(c: Context) {
        ctx = c.applicationContext
        YoutubeDL.getInstance().init(ctx)
        FFmpeg.getInstance().init(ctx)
    }

    /** Devolve [caminho do ffmpeg, LD_LIBRARY_PATH] testando de verdade qual binario executa. */
    fun findFfmpeg(): Array<String>? {
        val nativeDir = File(ctx.applicationInfo.nativeLibraryDir)
        val roots = listOf(nativeDir, ctx.noBackupFilesDir, ctx.filesDir, ctx.codeCacheDir)
        log("[ffmpeg] nativeDir=" + nativeDir.absolutePath + " arquivos=" +
            (nativeDir.list()?.sorted()?.joinToString(",") ?: "?"))
        val cands = LinkedHashSet<File>()
        for (r in roots) {
            r.walkTopDown().filter { it.isFile && it.name.contains("ffmpeg", true) && !it.name.contains("zip", true) }
                .forEach { cands.add(it) }
        }
        log("[ffmpeg] candidatos: " + cands.joinToString(" | ") { it.absolutePath + " (" + it.length() + ")" })
        val dirs = linkedSetOf(nativeDir.absolutePath)
        // inclui toda pasta com bibliotecas .so (o FFmpeg precisa de libc++_shared.so, que vem no pacote do Python)
        for (r in listOf(ctx.noBackupFilesDir, ctx.filesDir)) {
            r.walkTopDown().filter { it.isFile && (it.name.endsWith(".so") || it.name.contains(".so.")) }
                .forEach { dirs.add(it.parentFile!!.absolutePath) }
        }
        val ld = dirs.joinToString(":")
        log("[ffmpeg] LD_LIBRARY_PATH=$ld")
        for (c in cands) {
            c.setExecutable(true)
            if (works(c, ld)) return arrayOf(c.absolutePath, ld)
        }
        return null
    }

    private fun works(bin: File, ld: String): Boolean = try {
        val pb = ProcessBuilder(bin.absolutePath, "-version").redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = ld
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText()
        val ok = p.waitFor() == 0 && out.contains("ffmpeg", true)
        log("[ffmpeg] teste " + bin.absolutePath + ": ok=" + ok + " " + (out.lineSequence().firstOrNull() ?: ""))
        ok
    } catch (e: Throwable) {
        log("[ffmpeg] teste " + bin.absolutePath + " falhou: " + e.message)
        false
    }

    private fun log(s: String) {
        try {
            val f = File(ctx.filesDir, "clipstudio/ytdlp.log")
            if (f.length() > 300_000) f.writeText("")
            f.appendText(s + "\n")
        } catch (ignored: Throwable) {
        }
    }

    /** Roda o yt-dlp com os argumentos dados. Chama sink para cada linha de saida. */
    @JvmStatic
    fun ytdlp(args: Array<String>, procId: String, sink: LineSink?): YtResult {
        log("\n$ yt-dlp " + args.joinToString(" "))
        return try {
            val req = YoutubeDLRequest(emptyList<String>())
            req.addCommands(args.toList())
            val resp = YoutubeDL.getInstance().execute(req, procId) { _, _, line ->
                log(line)
                sink?.line(line)
            }
            log("[fim] codigo=${resp.exitCode} err=${(resp.err ?: "").takeLast(500)}")
            YtResult(resp.exitCode, resp.out ?: "", resp.err ?: "")
        } catch (e: Throwable) {
            log("[excecao] " + (e.message ?: e.toString()).takeLast(1500))
            if (e.javaClass.simpleName.contains("Cancel")) YtResult(-15, "", "cancelado")
            else YtResult(1, "", e.message ?: e.toString())
        }
    }

    @JvmStatic
    fun cancel(procId: String): Boolean = try {
        YoutubeDL.getInstance().destroyProcessById(procId)
    } catch (e: Throwable) {
        false
    }

    /** Atualiza o yt-dlp pela propria biblioteca (via reflexao, para nao depender do nome exato da API). */
    fun updateYtdlp(): String = try {
        val yd = YoutubeDL.getInstance()
        val m = yd.javaClass.methods.first { it.name == "updateYoutubeDL" && it.parameterTypes.size == 2 }
        val chType = m.parameterTypes[1]
        val channel: Any? = chType.enumConstants?.firstOrNull { it.toString().contains("STABLE", true) }
            ?: chType.fields.firstOrNull { it.name.contains("STABLE", true) }?.get(null)
            ?: chType.declaredFields.firstOrNull { it.name.contains("STABLE", true) }
                ?.apply { isAccessible = true }?.get(null)
        "yt-dlp: " + m.invoke(yd, ctx, channel)
    } catch (e: Throwable) {
        "yt-dlp: atualizacao falhou: " + (e.cause?.message ?: e.message)
    }

    @JvmStatic
    fun openUrl(url: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    @JvmStatic
    fun openFile(path: String) {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val mime = if (f.extension.lowercase() in setOf("png", "jpg", "jpeg", "webp")) "image/*" else "video/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Copia o video para Filmes/ClipStudio, para aparecer na Galeria. */
    @JvmStatic
    fun saveToGallery(path: String): Boolean {
        val src = File(path)
        if (!src.isFile) return false
        val resolver = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, src.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipStudio")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
        v.clear()
        v.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, v, null, null)
        return true
    }
}
